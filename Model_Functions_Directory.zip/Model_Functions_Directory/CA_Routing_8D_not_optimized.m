function [qout_left,qout_right,qout_up,qout_down,outlet_flow,qout_ne,qout_se,qout_sw,qout_nw,d_t,I_tot_end_cell,I] = CA_Routing_8D_not_optimized(elevation_cell,elevation_left_t,elevation_right_t,elevation_up_t,elevation_down_t,d_tot,d_left_cell,d_right_cell,d_up_cell,d_down_cell,roughness_cell,cell_area,time_step,h_0_cell,Resolution,I_tot_end_cell,outlet_index,outlet_type,slope_outlet,row_outlet,col_outlet,idx_nan,flag_critical,elevation_NE_t, elevation_SE_t, elevation_SW_t, elevation_NW_t, d_NE_t, d_SE_t, d_SW_t, d_NW_t,wse_slope_zeros,Distance_Matrix)
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                 %
%                 Produced by Marcus Nobrega Gomes Junior         %
%                 e-mail:marcusnobrega.engcivil@gmail.com         %
%                           September 2021                        %
%                                                                 %
%                 Last Updated: 7 July, 2022                      %
%                                                                 %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


%§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
%   -----  DESCRIPTION  -----
%   This function estimates the transfered volume from a cell to the
%   neighbour cells using a weigthing approach in terms of the available
%   volume in the neighbour cells
%§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
% ---------------% Finding Nans or Values Below a Threshold  % ---------------%
if isgpuarray(cell_area)
    d_t_min = gpuArray(1e-6); % m
else
    d_t_min = 1e-6; % m
end
idx3 = d_tot <= d_t_min*1000;
idx2 = idx_nan + idx3;
idx2 = idx2 > 0;
% ---------------% Adding minimum slope to do calculations % ---------------%
h_min = d_t_min;% m
I_tot_end_previous = I_tot_end_cell; 

% --------------- Notation  % ---------------%
%   <-I-> (left right up down) = [left ; right ; up; down]

% --------------- Cell Depth and Water surface Elevation  % ---------------%
depth_cell = d_tot./1000; % meters
wse_cell = elevation_cell + depth_cell;

% --------------- Depth Differences for All Cells  % ---------------%
delta_h(:,:,1) = (wse_cell - elevation_left_t - d_left_cell./1000); % left
delta_h(:,:,2) = (wse_cell - elevation_right_t - d_right_cell./1000); % right
delta_h(:,:,3) = (wse_cell - elevation_up_t - d_up_cell./1000); % up
delta_h(:,:,4) = (wse_cell - elevation_down_t - d_down_cell./1000); % down

% --------------- Depth Differences for All NE, SE, SW, NW  % ---------------%
% 6, 7, 8, 9, respectively
delta_h(:,:,6) = (wse_cell - elevation_NE_t - d_NE_t./1000); % NE
delta_h(:,:,7) = (wse_cell - elevation_SE_t - d_SE_t./1000); % SE
delta_h(:,:,8) = (wse_cell - elevation_SW_t - d_SW_t./1000); % SW
delta_h(:,:,9) = (wse_cell - elevation_NW_t - d_NW_t./1000); % NW

%%%%% CHECKED 9/28/2021 %%%%%
% --------------- Outlet Calculations  % ---------------%
if outlet_type == 1
    S_0 = slope_outlet; % Normal slope
    % V = h * area
    delta_h(:,:,5) = (S_0*Resolution*outlet_index); % Normal slope depth difference
    %%%%% CHECKED 9/28/2021 %%%%%
else
    S_0 = zeros(size(elevation_cell));
    for i = 1:length(row_outlet)
        % Checking left, right up, and down
        row = row_outlet(i); % Row of outlet
        col = col_outlet(i); % Col of outlet
        S_0(row,col) = (depth_cell(row,col).^(-1/6)).*sqrt(9.81).*roughness_cell(row,col); % Critical Slope
    end
    delta_h(:,:,5) = (S_0*Resolution);
end

% ---------------% Correcting delta_h  % ---------------%
% delta_h(logical(isnan(delta_h) + isinf(delta_h)) ) = 0; % TESTING
% delta_h(isnan(delta_h)) = 0; % TESTING

% ---------------% Boundary Conditions  % ---------------%
% These only applied when we are modeling a rectangular grid watershed
delta_h(:,1,1) = 0; % Left
%     direction = ones(size(delta_h(:,:,1)));
delta_h(:,end,2) = 0; % Right
delta_h(1,:,3) = 0; % Up
delta_h(end,:,4) = 0; % Down
delta_h(:,end,6) = 0; delta_h(1,:,6) = 0; % NE
delta_h(:,end,7) = 0; delta_h(end,:,7) = 0; % SE
delta_h(end,:,8) = 0; delta_h(:,1,8) = 0; % SW
delta_h(:,1,9) = 0; delta_h(1,:,9) = 0; % NW
idx = logical(delta_h < h_min | isnan(delta_h)); % A lot of attention here
delta_h(idx) = 0;

% ---------------% Available Volumes  % ---------------%
Vol = cell_area*delta_h; % 3-D Array with pages following direction notation
%%%%% CHECKED 9/28/2021 %%%%%
% ---------------% Minimum and Max Volumes  % ---------------%
% Minimum
c = 1000000; % large number
Vol_nan = Vol;
Vol_nan(idx) = c;
Vol_min_matrix = min(Vol_nan,[],3);
Vol_min_matrix(idx_nan) = nan; % ATTENTION HERE
% Total Volume
Vol_tot = sum(Vol,3);

% ---------------% Weights  % ---------------%
weight = Vol./(Vol_tot + Vol_min_matrix);
weight(isnan(weight)) = 0; % Attention here
weight_max = max(weight,[],3);
% weight_max(isnan(weight_max)) = 0; % Attention here

wse_slope = wse_slope_zeros;
Distance = Distance_Matrix;
% Slope
% if isgpuarray((Vol_tot))
%     wse_slope = gpuArray(zeros(size(delta_h)));
%     Distance = gpuArray(zeros(size(depth_cell)));
% else
%     wse_slope = zeros(size(delta_h));
%     Distance = zeros(size(depth_cell));
% end
wse_slope(:,:,1:4) = delta_h(:,:,1:4)/Resolution;
wse_slope(:,:,5) = delta_h(:,:,5)/Resolution;
wse_slope(:,:,6:end) = delta_h(:,:,6:end)/(sqrt(2)*Resolution);
[sf,index] = max(wse_slope,[],3); % Maximum Slope

idx = index <= 5;
Distance(idx) = Resolution;
Distance(idx == 0) = sqrt(2)*Resolution;


% for i = 1:9
%     idx = wse_slope(:,:,i) == sf;
%     if ~isempty(idx)
%         if i <= 5
%             Distance(idx) = Resolution;
%         else
%             Distance(idx) = sqrt(2)*Resolution;
%         end
%     end
% end

%% ---------------% Velocity Calculation %---------------%
% Velocity to the cell with the highest gradient
if flag_critical == 1
    v_m = min(sqrt(9.81.*depth_cell),1./roughness_cell.*((max(depth_cell - h_0_cell/1000,0))).^(2/3).*sqrt(sf));
else
    v_m = 1./roughness_cell.*((max(depth_cell - h_0_cell/1000,0))).^(2/3).*sqrt(sf);% Manning's equation only
end
%% ---------------% Intercell Volume Calculation %---------------%
% Estimated Volume that goes to the cell with the highest gradient
%         I_m = v_m.*depth_cell*Resolution*time_step*60; % Velocity x Area x Time_step (m3)

% ---------------% Total outflow volume % ---------------%
%%%% In case we won't want to input I_tot_end_previous %%%
if sum(sum(I_tot_end_previous)) == 0
    I_tot_end_previous = 0.9*cell_area*depth_cell;
    I_tot_end_previous(isnan(I_tot_end_previous)) = 0;
end
% I_tot_end = min(depth_cell*cell_area,I_m/max(weight),Vol_min_matrix + I_tot_begin);
I_tot_end_cell = min(depth_cell.*cell_area,v_m.*depth_cell./weight_max.*(Distance*time_step*60)); % m3
I_tot_end_cell = min(I_tot_end_cell,I_tot_end_previous + Vol_min_matrix);
I_tot_end_cell(idx2) = 0;  % If the depth is smaller than dmin ATTENTION HERE

% ---------------% Outflow Volume to each direction % ---------------%
I = weight.*I_tot_end_cell; % m3
I_tot_end_cell = sum(I,3);% Volume that leaves the cell in m3
qout = I./(time_step*60)/(cell_area)*1000*3600; % mm/hr
qout_left = qout(:,:,1);
qout_right = qout(:,:,2);
qout_up = qout(:,:,3);
qout_down = qout(:,:,4);
outlet_flow = qout(:,:,5);
% Inclined Directions
qout_ne = qout(:,:,6);
qout_se = qout(:,:,7);
qout_sw = qout(:,:,8);
qout_nw = qout(:,:,9);
% outlet_volume = I(:,:,5);
%% ---------------% Final depth at the cell % ---------------%
d_t = d_tot - I_tot_end_cell/cell_area*1000; % final depth in mm;
end