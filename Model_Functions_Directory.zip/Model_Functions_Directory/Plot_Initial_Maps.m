% HydroPol2D Input Maps
% Developer: Marcus Nobrega
% Date 6/21/2023
% Goal: Plot Initial Maps

x_grid = GIS_data.xulcorner + Wshed_Properties.Resolution*[1:1:size(DEM_raster.Z,2)]; y_grid = GIS_data.yulcorner - Wshed_Properties.Resolution*[1:1:size(DEM_raster.Z,1)];
filename = 'Input_Maps';
set(gcf,'units','inches','position',[2,0,10,8])
% -------- Manning  -------- %
t_title = 'Manning';
ax1 = subplot(3,2,1);
axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
z = LULC_Properties.roughness; z(idx_nan) = nan;
idx = z < 0;
z(idx) = nan;
idx = isinf(z);
z(idx) = nan;
xmax = size(z,2);
xend = xmax;
ymax = size(z,1);
yend = ymax;
h_min = min(min(z));
F = z;
zmax = max(max(z(~isnan(z))));
if isempty(zmax) || isinf(zmax) || zmax == 0
    zmax = 0.1;
end
map = surf(x_grid,y_grid,F);
set(map,'LineStyle','none'); axis tight; grid on; box on; % this ensures that getframe() returns a consistent size; axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
title((t_title),'Interpreter','Latex','FontSize',12)
view(0,90)
if h_min == zmax
    zmax = 2*h_min;
end
caxis([h_min zmax]);
colormap(jet)
hold on
k = colorbar ;
ylabel(k,'$n$ ($\mathrm{s.m^{-1/3}}$)','Interpreter','Latex','FontSize',12)
xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
zlabel ('$n$ ($\mathrm{sm^{-1/3}}$)','Interpreter','Latex','FontSize',12)
set(gca, 'FontName', 'Garamond', 'FontSize', 12)
set(gca, 'TickLength', [0.02 0.01]);
set(gca,'Tickdir','out')
% ---------- h_0 --------------- %

ax2 = subplot(3,2,2);
t_title = 'Initial Abstraction';
axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
z = LULC_Properties.h_0; z(idx_nan) = nan;
idx = z < 0;
z(idx) = nan;
idx = isinf(z);
z(idx) = nan;
xmax = size(z,2);
xend = xmax;
ymax = size(z,1);
yend = ymax;
h_min = min(min(z));
F = z;
zmax = max(max(z(~isnan(z))));
if isempty(zmax) || isinf(zmax) || zmax == 0
    zmax = 0.1;
end
map = surf(x_grid,y_grid,F);
set(map,'LineStyle','none'); axis tight; grid on; box on; % this ensures that getframe() returns a consistent size; axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
title((t_title),'Interpreter','Latex','FontSize',12)
view(0,90)
if h_min == zmax
    zmax = 2*h_min;
end
caxis([h_min zmax]);
colormap(jet)
hold on
k = colorbar ;
ylabel(k,'$h_0$ ($\mathrm{mm})$','Interpreter','Latex','FontSize',12)
xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
zlabel ('$h_0$ ($\mathrm{mm}$)','Interpreter','Latex','FontSize',12)
set(gca, 'FontName', 'Garamond', 'FontSize', 12)
set(gca, 'TickLength', [0.02 0.01]);
set(gca,'Tickdir','out')

% ----------  k_sat ------------- %
ax3 = subplot(3,2,3);
t_title = 'Sat. Hyd. Conductivity';
axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
z = Soil_Properties.ksat; z(idx_nan) = nan;
idx = z < 0;
z(idx) = nan;
idx = isinf(z);
z(idx) = nan;
xmax = size(z,2);
xend = xmax;
ymax = size(z,1);
yend = ymax;
h_min = min(min(z));
F = z;
zmax = max(max(z(~isnan(z))));
if isempty(zmax) || isinf(zmax) || zmax == 0
    zmax = 0.1;
end
map = surf(x_grid,y_grid,F);
set(map,'LineStyle','none'); axis tight; grid on; box on; % this ensures that getframe() returns a consistent size; axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
title((t_title),'Interpreter','Latex','FontSize',12)
view(0,90)
if h_min == zmax
    zmax = 2*h_min;
end
caxis([h_min zmax]);
colormap(jet)
hold on
k = colorbar ;
ylabel(k,'$k_{sat}$ ($\mathrm{mm/h})$','Interpreter','Latex','FontSize',12)
xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
zlabel ('$k_{sat}$ ($\mathrm{mm/h}$)','Interpreter','Latex','FontSize',12)
set(gca, 'FontName', 'Garamond', 'FontSize', 12)
set(gca, 'TickLength', [0.02 0.01]);
set(gca,'Tickdir','out')

% ----------  dtheta ------------- %
ax4 = subplot(3,2,4);
t_title = 'Moisture Deficit';
axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
z = (Soil_Properties.teta_sat - Soil_Properties.teta_i); z(idx_nan) = nan;
idx = z < 0;
z(idx) = nan;
idx = isinf(z);
z(idx) = nan;
xmax = size(z,2);
xend = xmax;
ymax = size(z,1);
yend = ymax;
h_min = min(min(z));
F = z;
zmax = max(max(z(~isnan(z))));
if isempty(zmax) || isinf(zmax) || zmax == 0
    zmax = 0.1;
end
map = surf(x_grid,y_grid,F);
set(map,'LineStyle','none'); axis tight; grid on; box on; % this ensures that getframe() returns a consistent size; axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
title((t_title),'Interpreter','Latex','FontSize',12)
view(0,90)
if h_min == zmax
    zmax = 2*h_min;
end
caxis([h_min zmax]);
colormap(jet)
hold on
k = colorbar ;
ylabel(k,'$\Delta \theta$ ($\mathrm{cm^3.cm^{-3}})$','Interpreter','Latex','FontSize',12)
xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
zlabel ('$\Delta \theta$ ($\mathrm{cm^3.cm^{-3}}$)','Interpreter','Latex','FontSize',12)
set(gca, 'FontName', 'Garamond', 'FontSize', 12)
set(gca, 'TickLength', [0.02 0.01]);
set(gca,'Tickdir','out')

% ----------  F_0 ------------- %
ax5 = subplot(3,2,5);
t_title = 'Initial Soil Content';
z = Soil_Properties.I_0; z(idx_nan) = nan;
idx = z < 0;
z(idx) = nan;
idx = isinf(z);
z(idx) = nan;
xmax = size(z,2);
xend = xmax;
ymax = size(z,1);
yend = ymax;
h_min = min(min(z));
F = z;
zmax = max(max(z(~isnan(z))));
if isempty(zmax) || isinf(zmax) || zmax == 0
    zmax = 0.1;
end
map = surf(x_grid,y_grid,F);
set(map,'LineStyle','none'); axis tight; grid on; box on; % this ensures that getframe() returns a consistent size; axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
title((t_title),'Interpreter','Latex','FontSize',12)
view(0,90)
if h_min == zmax
    zmax = 2*h_min;
end
caxis([h_min zmax]);
colormap(jet)
hold on
k = colorbar ;
ylabel(k,'$F_0$ ($\mathrm{m}$)','Interpreter','Latex','FontSize',12)
xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
zlabel ('$I_0$ ($\mathrm{m}$)','Interpreter','Latex','FontSize',12)
set(gca, 'FontName', 'Garamond', 'FontSize', 12)
set(gca, 'TickLength', [0.02 0.01]);
set(gca,'Tickdir','out')

% ----------  D_0 ------------- %
ax6 = subplot(3,2,6);
t_title = 'Initial Water Depth';
axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
z = depths.d_0/1000; z(idx_nan) = nan;
idx = z < 0;
z(idx) = nan;
idx = isinf(z);
z(idx) = nan;
xmax = size(z,2);
xend = xmax;
ymax = size(z,1);
yend = ymax;
h_min = min(min(z));
F = z;
zmax = max(max(z(~isnan(z))));
if isempty(zmax) || isinf(zmax) || zmax == 0
    zmax = 0.1;
end
map = surf(x_grid,y_grid,F);
set(map,'LineStyle','none'); axis tight; grid on; box on; % this ensures that getframe() returns a consistent size; axis tight; grid on; box on; % this ensures that getframe() returns a consistent size
title((t_title),'Interpreter','Latex','FontSize',12)
view(0,90)
if h_min == zmax
    zmax = 2*h_min;
end
caxis([h_min zmax]);
colormap(jet)
hold on
k = colorbar ;
ylabel(k,'$d_{0}$ ($\mathrm{m}$)','Interpreter','Latex','FontSize',12)
xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
zlabel ('$d_{0}^0$ ($\mathrm{m}$)','Interpreter','Latex','FontSize',12)
set(gca, 'FontName', 'Garamond', 'FontSize', 12)
set(gca, 'TickLength', [0.02 0.01]);
set(gca,'Tickdir','out')

exportgraphics(gcf,'Input_Maps.TIF','ContentType','image','Colorspace','rgb','Resolution',800)
close all