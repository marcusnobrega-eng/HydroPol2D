
% Run Optimal
x_optimal = x;
[~,Qmod_optimal,Cmod_optimal] = HydroPol2D_Solver_with_x(x,flag_calibrate_wq,idx_imp,idx_lulc,idx_soil,n_LULC,n_SOIL,ADD_events,delta_p_obs,warmup_depths,warmup_I_0,n_events,time_observed,observed_flow,pollutant_concentration , alfa_albedo_input	, alfa_max	, alfa_min	, alfa_save	, avgtemp_stations	, B_t , Bmax	, Bmin	, C	 , C_3	, C_4	, Cd	, cell_area	, climatologic_spatial_duration	, col_outlet	, coordinate_x	, coordinate_y	, coordinates_stations	, d_0	, d_p	, date_begin	, delta_p_agg	, dem	, DEM_etp	, DEM_raster	, depth_tolerance	, elevation	, elevation_down_t	, elevation_left_t	, elevation_right_t	, elevation_up_t	, ETP	, ETP_save	, factor_cells	, flag_critical	, flag_D8	, flag_ETP	, flag_infiltration	, flag_inflow	, flag_rainfall	, flag_spatial_rainfall	, flag_timestep		, flag_waterquality	, flag_wq_model	, flow_acceleration	, flow_tolerance	, flows_cells	, G_stations	, gravity	, h_0	, h_0_fulldomain		, I_tot_end	, I_tot_end_cell, idx_nan	, idx_nan_5	, inflow	, inflow_cells	, k	, k_out	, Krs	, ksat_fulldomain	, last_record_maps	, lat	, mass_lost	, mass_outlet	, max_time_step	, maxtemp_stations	, min_Bt	, min_time_step	, mintemp_stations	, mu	, n_stream_gauges	, nx_max	, ny_max		, Out_Conc	, outlet_index	, outlet_index_fulldomain	, outlet_type	, P_conc	, psi_fulldomain	, rainfall_matrix	, rainfall_matrix_full_domain	, Resolution	, ro_water	, roughness	, roughness_fulldomain		, row_outlet	, slope_alfa	, slope_outlet		, spatial_domain	, t	, t_previous		, teta_i_fulldomain	, teta_sat	, teta_sat_fulldomain	, time_calculation_routing	, time_change_matrices	, time_change_records	, time_deltap	, time_ETP	, time_records	, time_save_previous	, time_step	, time_step_change	, time_step_increments	, time_step_model	, time_step_save	, tmin_wq	, Tot_Washed	, Tr	, u2_stations	, ur_stations	, v_threshold	, vel_down	, vel_left	, vel_right	, vel_up	, vol_outlet	, weight_person, width1_person, width2_person);

[Obj_fun] = Objective_Function_HydroPol2D(x,flag_calibrate_wq,idx_imp,idx_lulc,idx_soil,n_LULC,n_SOIL,ADD_events,delta_p_obs,warmup_depths,warmup_I_0,n_events,time_observed,observed_flow,pollutant_concentration , alfa_albedo_input	, alfa_max	, alfa_min	, alfa_save	, avgtemp_stations	, B_t , Bmax	, Bmin	, C	 , C_3	, C_4	, Cd	, cell_area	, climatologic_spatial_duration	, col_outlet	, coordinate_x	, coordinate_y	, coordinates_stations	, d_0	, d_p	, date_begin	, delta_p_agg	, dem	, DEM_etp	, DEM_raster	, depth_tolerance	, elevation	, elevation_down_t	, elevation_left_t	, elevation_right_t	, elevation_up_t	, ETP	, ETP_save	, factor_cells	, flag_critical	, flag_D8	, flag_ETP	, flag_infiltration	, flag_inflow	, flag_rainfall	, flag_spatial_rainfall	, flag_timestep		, flag_waterquality	, flag_wq_model	, flow_acceleration	, flow_tolerance	, flows_cells	, G_stations	, gravity	, h_0	, h_0_fulldomain		, I_tot_end	, I_tot_end_cell, idx_nan	, idx_nan_5	, inflow	, inflow_cells	, k	, k_out	, Krs	, ksat_fulldomain	, last_record_maps	, lat	, mass_lost	, mass_outlet	, max_time_step	, maxtemp_stations	, min_Bt	, min_time_step	, mintemp_stations	, mu	, n_stream_gauges	, nx_max	, ny_max		, Out_Conc	, outlet_index	, outlet_index_fulldomain	, outlet_type	, P_conc	, psi_fulldomain	, rainfall_matrix	, rainfall_matrix_full_domain	, Resolution	, ro_water	, roughness	, roughness_fulldomain		, row_outlet	, slope_alfa	, slope_outlet		, spatial_domain	, t	, t_previous		, teta_i_fulldomain	, teta_sat	, teta_sat_fulldomain	, time_calculation_routing	, time_change_matrices	, time_change_records	, time_deltap	, time_ETP	, time_records	, time_save_previous	, time_step	, time_step_change	, time_step_increments	, time_step_model	, time_step_save	, tmin_wq	, Tot_Washed	, Tr	, u2_stations	, ur_stations	, v_threshold	, vel_down	, vel_left	, vel_right	, vel_up	, vol_outlet	, weight_person, width1_person, width2_person);




if flag_waterquality ~= 1
    for jj = 1:n_events
        if n_events > 1
            col = 2;
        else
            col = 1;
        end        
        subplot(n_events,col,ii);
        plot(time_observed,Qmod_optimal,'-black','Marker','*')
        hold on
        plot(time_observed,obs_discharge,'--b','Marker','*')
        xlabel('Elapsed time (min)','FontSize',12,'Interpreter','latex')
        ylabel('Discharge ($m^3/s$)','FontSize',12,'Interpreter','latex')
        legend('Modeled','Observed','interpreter','latex')        
    end
else
    for jj = 1:n_events
        if n_events > 1
            col = 2;
        else
            col = 1;
        end
        subplot(n_events,col,ii);
        plot(time_observed,Cmod_optimal,'-black','Marker','*')
        hold on
        plot(time_observed,pollutant_concentration,'--b','Marker','*')
        xlabel('Elapsed time (min)','FontSize',12,'Interpreter','latex')
        ylabel('Pollutant Concentration ($mg/L$)','FontSize',12,'Interpreter','latex')
        legend('Modeled','Observed','interpreter','latex')
    end
end
pause(0.25)