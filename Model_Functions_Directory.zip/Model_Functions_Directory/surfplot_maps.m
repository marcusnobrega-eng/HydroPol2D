% Map Scaled Plot
function [axis] = surfplot_maps(DEM_raster,matrix,coloramp,x_label,y_label,z_label,no_data_value,idx_nan,row,col,index,size_font)
    hold on;
    % Matrix
    strcat('ax',num2str(index)) = subplot(row,col,index);
    z = matrix; % Infiltration Map
    z(z<0)=nan; % Taking away negative values
    zmax = max(max(max(z))); zmin = min(min(min(z))); z(idx_nan) = no_data_value;
    % Using DEM as a reference
    F = DEM_raster; % Just to get a coordinate system
    F.Z = z;
    % Plotting Hillshade + Data
    imageschs(DEM_raster,F,'colormap',coloramp);
    view(0,90);
    colorbar
    if zmin == zmax
        zmax = zmin*2;
    end
    if zmin == 0 && zmin == zmax
        zmax = zmin + 10;
    end
    caxis([zmin zmax]);
    k = colorbar;
    k.TickDirection = 'out';
    ylabel(k,z_label,'Interpreter','Latex','FontSize',size_font)
    xlabel(x_label,'Interpreter','Latex','FontSize',size_font)
    ylabel(y_label,'Interpreter','Latex','FontSize',size_font)    
    zlabel (z_label,'Interpreter','Latex','FontSize',size_font)
    set(gca, 'TickLength', [0.02 0.01]);
    set(gca,'Tickdir','out')
    set(gca, 'FontName', 'Garamond', 'FontSize', 12)
    title(z_label,'Interpreter','Latex');
    grid off
    box on ;
    axis = gca;
end