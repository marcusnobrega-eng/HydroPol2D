%% HydroPol2D Model
% Developer: Marcus Nobrega
% Main Script
% % % % % % % % % % % % % Model Status % % % % % % % % % % % % %
% ---------- Version 11.0 -------------
% Last Update - 6/22/2023
% Next step - Clear variables

% ----------------- Initial Data - General -----------------
clc
clear all
tic

%% Pre-Processing
clear all; clc;
input_table = readtable('general_data.xlsx'); 

% Load Model Functions
HydroPol2D_tools = char(table2cell(input_table(9,31)));
addpath(genpath(char(HydroPol2D_tools)));
HydroPol2D_preprocessing

HydroPol2D_preprocessing
%% Main While Loop
HydroPol2D_Main_While; % Runs the Main While Loop of the Model

%% Post-Processing Results

close all
post_processing