%%% Inundation Maps %%%
% Creates .GIF files from the saved data
% Last updated: 10/4/2021

close all
f = 1;
t_max = running_control.routing_time;
tfinal = t_max ; %t_max;
DEM_maps = gather(Elevation_Properties.elevation_cell);

%% Time Data
if flags.flag_elapsed_time ~=1.
    if flags.flag_spatial_rainfall == 1
        if ~isdatetime(Spatial_Rainfall_Parameters.rainfall_spatial_duration)
            Spatial_Rainfall_Parameters.rainfall_spatial_duration = Spatial_Rainfall_Parameters.rainfall_spatial_duration/60/24 + date_begin;
        end
    end
    if flags.flag_ETP == 1
        if ~isdatetime(ETP_Parameters.climatologic_spatial_duration)
            ETP_Parameters.climatologic_spatial_duration = ETP_Parameters.climatologic_spatial_duration/60/24 + date_begin;
        end
    end
    if ~isdatetime(running_control.time_records)
        running_control.time_records =  double(running_control.time_records/60/24) + date_begin;
    end
end


%% Plot Elevation Model
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
FileName_String = 'Elevation_Model.gif';
FileName = fullfile(folderName,strcat('\',FileName_String));

a_grid = Wshed_Properties.Resolution;
b_grid = Wshed_Properties.Resolution;
tmax = 10;
for t = 1:tmax
    % Draw plot
    z = DEM_maps;
    xmax = length(z(1,:));
    xend = xmax;
    ymax = length(z(:,1));
    yend = ymax;
    xbegin = 1;
    ybegin = 1;
    max_h = max(max(max(z)));
    h_max = round(max_h/10,0)*10*1.05;
    % UTM Coordinates
    x_grid = GIS_data.xulcorner + a_grid*[xbegin:1:xend]; y_grid = GIS_data.yulcorner - a_grid*[ybegin:1:yend];
    %     y_grid = flip(y_grid); % Make sure we plot the graphs properly with y towards vertical top.
    z(z<=0)=inf;
    h_min = min(min(z));
    F = DEM_maps([ybegin:1:yend],[xbegin:1:xend]);
    zmax = max(max(max(z(~isinf(z)))));
    kk = surf(x_grid,y_grid,F);
    set(kk,'LineStyle','none');
    set(gca,'XTickLabel',x_grid)
    set(gca,'YTickLabel',y_grid)
    axis([min(min(x_grid)) max(max(x_grid)) min(min(y_grid)) max(max(y_grid)) h_min zmax])
    view(-(t-1)*360/tmax,(t-1)*90/tmax);
    colorbar
    caxis([h_min zmax]);
    colormap(terrain_ramp)
    box on
    hold on
    title('Elevation','Interpreter','Latex','FontSize',12)
    k = colorbar ;
    ylabel(k,'Elevation (m)','Interpreter','Latex','FontSize',12)
    xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
    ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
    zlabel ('Elevation (m)','Interpreter','Latex','FontSize',12)
    set(gca,'FontName','Garamond')
    drawnow
    % Capture the plot as an image
    frame = getframe(h);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    % Write to the GIF File
    if t == 1
        imwrite(imind,cm,FileName,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,FileName,'gif','WriteMode','append');
    end
end
clf
%% Plot Water Surface Elevation and Depths
% Adjusting the size
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
FileName_String = 'WSE_and_Depths.gif';
FileName = fullfile(folderName,strcat('\',FileName_String));

set(gcf,'units','inches','position',[0,0,7,12])
idx2 = Maps.Hydro.d < depths.depth_wse*1000;
z1 = gather(Maps.Hydro.d)/1000 + DEM_maps;
z1(z1<=0)=nan;
z1(idx2) = nan;

z2 = gather(Maps.Hydro.d/1000);
z2(z2<=0)=nan;
z2(idx2)=nan;

for t = 1:f:length(running_control.time_records)
    subplot(2,1,1)
    t_title = running_control.time_records(t);

    zmax = max(max(max(z1)));
    zmin = min(min(min(z1)));
    if isnan(zmax)
        zmax = 10;
    end
    if isnan(zmin)
        zmin = 0;
    end
    F = z1([ybegin:1:yend],[xbegin:1:xend],t);
    F(idx2(:,:,t)) = 0;
    surf(x_grid,y_grid,F);
    shading INTERP;

    axis([min(min(x_grid)) max(max(x_grid)) min(min(y_grid)) max(max(y_grid)) zmin zmax])
    if flags.flag_elapsed_time == 1
        title(sprintf('Time(h) = %4.2f',t_title/60),'Interpreter','Latex','FontSize',12)
    else
        title(sprintf(string(t_title)),'Interpreter','Latex','FontSize',12);
    end

    view(0,90);
    colorbar
    caxis([zmin zmax]);
    colormap(depth_ramp)
    k = colorbar;
    ylabel(k,'WSE (m)','Interpreter','Latex','FontSize',12)
    xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
    ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
    zlabel ('WSE (m)','Interpreter','Latex','FontSize',12)
    set(gca,'FontName','Garamond')
    box on
    drawnow

    subplot(2,1,2)

    % zmax = max(max(max(z2(~isinf(z2)))));
    % zmin = min(min(min(z2)));
    zmax = max(max(max(z2)));
    zmin = min(min(min(z2)));
    if isnan(zmax)
        zmax = 10;
    end
    if isnan(zmin)
        zmin = 0;
    end
    F = z2([ybegin:1:yend],[xbegin:1:xend],t);
    F(idx2(:,:,t)) = 0;
    surf(x_grid,y_grid,F);
    axis([min(min(x_grid)) max(max(x_grid)) min(min(y_grid)) max(max(y_grid)) zmin zmax])

    shading INTERP;
    if flags.flag_elapsed_time == 1
        title(sprintf('Time(h) = %4.2f',t_title/60),'Interpreter','Latex','FontSize',12)
    else
        title(sprintf(string(t_title)),'Interpreter','Latex','FontSize',12);
    end
    view(0,90);
    colorbar
    caxis([0 zmax]);
    colormap(depth_ramp)
    k = colorbar;

    ylabel(k,'Depths (m)','Interpreter','Latex','FontSize',12)
    xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
    ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
    zlabel ('WSE (m)','Interpreter','Latex','FontSize',12)
    set(gca,'FontName','Garamond')

    box on
    grid on
    % Capture the plot as an image
    frame = getframe(h);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    % Write to the GIF File
    if t == 1
        imwrite(imind,cm,FileName,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,FileName,'gif','WriteMode','append');
    end
end
clf
close all

%% Flag_Spatial_Rainfall
if flags.flag_spatial_rainfall == 1 && flags.flag_rainfall == 1 && flags.flag_input_rainfall_map ~= 1
    close all
    h = figure;
    axis tight manual % this ensures that getframe() returns a consistent size
    FileName_String = 'Rainfall_Maps.gif';
    FileName = fullfile(folderName,strcat('\',FileName_String));
    set(gcf,'units','inches','position',[3,3,6.5,4])


    zmax = max(max(max(Maps.Hydro.spatial_rainfall_maps)));
    zmin = min(min(min(Maps.Hydro.spatial_rainfall_maps)));
    if zmin == zmax
        zmax = zmin + 10; % mm/h
    end

    for t = 1:(size(Maps.Hydro.spatial_rainfall_maps,3)-1)
        rain = Maps.Hydro.spatial_rainfall_maps(:,:,t);
        idx = isnan(Elevation_Properties.elevation_cell);
        rain(rain<=0) = nan;
        rain(idx) = nan;
        spatial_rainfall = rain;
        if t > size(Spatial_Rainfall_Parameters.rainfall_spatial_duration,2)
            t_title = Spatial_Rainfall_Parameters.rainfall_spatial_duration(end) + Spatial_Rainfall_Parameters.rainfall_spatial_duration_agg(2);
            rainfall = zeros(size(Elevation_Properties.elevation_cell));
            z = rainfall;
            plot3(Spatial_Rainfall_Parameters.x_coordinate, Spatial_Rainfall_Parameters.y_coordinate,zmax*ones(size(rainfall)), 'r.', 'MarkerSize', 30)
        else
            t_title = Spatial_Rainfall_Parameters.rainfall_spatial_duration(t);
            % Draw plot for d = x.^n
            z = rain; %
            z(idx_nan)=nan;
            rainfall = Spatial_Rainfall_Parameters.rainfall_raingauges(t,1:Spatial_Rainfall_Parameters.n_raingauges)';
            plot3(Spatial_Rainfall_Parameters.x_coordinate, Spatial_Rainfall_Parameters.y_coordinate,zmax*ones(size(rainfall)), 'r.', 'MarkerSize', 30)
        end
        hold on
        F = z([ybegin:1:yend],[xbegin:1:xend]);
        surf(x_grid,y_grid,F);
        axis([min(min(x_grid)) max(max(x_grid)) min(min(y_grid)) max(max(y_grid)) zmin zmax])

        shading INTERP;

        %
        if flags.flag_elapsed_time == 1
            title(sprintf('Time(h) = %4.2f',t_title/60),'Interpreter','Latex','FontSize',12)
        else
            title(sprintf(string(t_title)),'Interpreter','Latex','FontSize',12);
        end
        view(0,90);
        colorbar
        caxis([zmin zmax]);
        colormap(linspecer)
        k = colorbar;
        ylabel(k,'Rainfall (mm/h)','Interpreter','Latex','FontSize',12)
        xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
        ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
        zlabel ('Rainfall (mm/h)','Interpreter','Latex','FontSize',12)
        set(gca,'FontName','Garamond')

        box on
        set(gca,'tickdir','out');
        set(gca, 'TickLength', [0.02 0.01]);
        set(gca,'Tickdir','out')
        set(gca,'FontName','Garamond');
        drawnow
        hold off
        % Capture the plot as an image
        frame = getframe(h);
        im = frame2im(frame);
        [imind,cm] = rgb2ind(im,256);
        % Write to the GIF File
        if t == 1
            imwrite(imind,cm,FileName,'gif', 'Loopcount',inf);
        else
            imwrite(imind,cm,FileName,'gif','WriteMode','append');
        end
    end
end

%% Flag_Spatial_Rainfall - Input Maps
if flags.flag_spatial_rainfall == 1 && flags.flag_rainfall == 1 && flags.flag_input_rainfall_map == 1
    close all
    h = figure;
    axis tight manual % this ensures that getframe() returns a consistent size
    FileName_String = 'Rainfall_Maps.gif';
    FileName = fullfile(folderName,strcat('\',FileName_String));
    set(gcf,'units','inches','position',[3,3,6.5,4])


    zmax = max(max(max(Maps.Hydro.spatial_rainfall_maps)));
    zmin = min(min(min(Maps.Hydro.spatial_rainfall_maps)));
    if zmin == zmax
        zmax = zmin + 10; % mm/h
    end

    for t = 1:(size(Maps.Hydro.spatial_rainfall_maps,3)-1)
        clf
        rain = Maps.Hydro.spatial_rainfall_maps(:,:,t);
        idx = isnan(Elevation_Properties.elevation_cell);
        rain(rain<0) = nan;
        rain(idx) = nan;
        spatial_rainfall = rain;
        if t > length(Spatial_Rainfall_Parameters.rainfall_spatial_duration)
            t_title = Spatial_Rainfall_Parameters.rainfall_spatial_duration(end) + Spatial_Rainfall_Parameters.rainfall_spatial_duration_agg(2);
            rainfall = zeros(size(Elevation_Properties.elevation_cell));
            z = rainfall;
        else
            t_title = Spatial_Rainfall_Parameters.rainfall_spatial_duration(t);
            % Draw plot for d = x.^n
            z = rain; %
            z(idx_nan)=nan;
        end
        hold on
        F = z([ybegin:1:yend],[xbegin:1:xend]);
        surf(x_grid,y_grid,F);
        axis([min(min(x_grid)) max(max(x_grid)) min(min(y_grid)) max(max(y_grid)) zmin zmax])

        shading INTERP;

        %
        if flags.flag_elapsed_time == 1
            title(sprintf('Time(h) = %4.2f',t_title/60),'Interpreter','Latex','FontSize',12)
        else
            title(sprintf(string(t_title)),'Interpreter','Latex','FontSize',12);
        end
        view(0,90);
        colorbar
        caxis([zmin zmax]);
        colormap(linspecer)
        k = colorbar;
        ylabel(k,'Rainfall (mm/h)','Interpreter','Latex','FontSize',12)
        xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
        ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
        zlabel ('Rainfall (mm/h)','Interpreter','Latex','FontSize',12)
        set(gca,'FontName','Garamond')

        box on
        set(gca,'tickdir','out');
        set(gca, 'TickLength', [0.02 0.01]);
        set(gca,'Tickdir','out')
        set(gca,'FontName','Garamond');
        drawnow
        hold off
        % Capture the plot as an image
        frame = getframe(h);
        im = frame2im(frame);
        [imind,cm] = rgb2ind(im,256);
        % Write to the GIF File
        if t == 1
            imwrite(imind,cm,FileName,'gif', 'Loopcount',inf);
        else
            imwrite(imind,cm,FileName,'gif','WriteMode','append');
        end
    end
end


%% Flag_ETP
if flags.flag_ETP == 1
    close all
    h = figure;
    axis tight manual % this ensures that getframe() returns a consistent size
    FileName_String = 'ETP.gif';
    FileName = fullfile(folderName,strcat('\',FileName_String));

    set(gcf,'units','inches','position',[3,3,6.5,4])

    zmax = max(max(max(ETP_save)));
    zmin = min(min(min(ETP_save)));
    if zmin == zmax
        zmax = zmin + 10; % mm/h
    end

    for t = 1:(size(ETP_save,3))
        ETP = ETP_save(:,:,t);
        idx = isnan(Elevation_Properties.elevation_cell);
        ETP(ETP<=0) = nan;
        ETP(idx) = nan;
        spatial_ETP = ETP;
        t_title = ETP_Parameters.climatologic_spatial_duration(t);
        % Draw plot for d = x.^n
        z = ETP; %
        z(idx_nan)=nan;
        hold on
        F = z([ybegin:1:yend],[xbegin:1:xend]);
        surf(x_grid,y_grid,F);
        axis tight
        shading INTERP;

        %
        if flags.flag_elapsed_time == 1
            title(sprintf('Time(h) = %4.2f',t_title/60),'Interpreter','Latex','FontSize',12)
        else
            title(sprintf(string(t_title)),'Interpreter','Latex','FontSize',12);
        end
        view(0,90);
        colorbar
        caxis([zmin zmax]);
        colormap(linspecer)
        k = colorbar;
        ylabel(k,'ETP (mm/day)','Interpreter','Latex','FontSize',12)
        xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
        ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
        zlabel ('ETP (mm/day)','Interpreter','Latex','FontSize',12)
        set(gca,'FontName','Garamond')

        drawnow
        box on
        set(gca,'tickdir','out');
        set(gca, 'TickLength', [0.02 0.01]);
        set(gca,'Tickdir','out')
        set(gca,'FontName','Garamond');


        hold off
        % Capture the plot as an image
        frame = getframe(h);
        im = frame2im(frame);
        [imind,cm] = rgb2ind(im,256);
        % Write to the GIF File
        if t == 1
            imwrite(imind,cm,FileName,'gif', 'Loopcount',inf);
        else
            imwrite(imind,cm,FileName,'gif','WriteMode','append');
        end
    end
end
close all
%% Plot Risk Maps
% Adjusting the size
if flags.flag_human_instability == 1
    h = figure;
    axis tight manual % this ensures that getframe() returns a consistent size
    FileName_String = 'Slide_Risk.gif';
    FileName = fullfile(folderName,strcat('\',FileName_String));

    set(gcf,'units','inches','position',[0,0,6.5,4])
    for t = 1:f:length(running_control.time_records)
        t_title = running_control.time_records(t);
        % Draw plot for d = x.^n
        z = Maps.Hydro.risk*100; %plotting only the excedance of the h_0
        z(isinf(z)) = nan;
        %     idx2 = z < 0.05;
        %     z(idx2) = nan;
        zmax = max(max(max(z)));
        zmin = min(min(min(z)));

        F = z([ybegin:1:yend],[xbegin:1:xend],t);
        surf(x_grid,y_grid,F);
        if zmin == zmax
            zmax = zmin + 1;
        end
        axis([min(min(x_grid)) max(max(x_grid)) min(min(y_grid)) max(max(y_grid)) zmin zmax])

        shading INTERP;
        %
        if flags.flag_elapsed_time == 1
            title(sprintf('Time(h) = %4.2f',t_title/60),'Interpreter','Latex','FontSize',12)
        else
            title(sprintf(string(t_title)),'Interpreter','Latex','FontSize',12);
        end
        view(0,90);
        colorbar
        caxis([zmin zmax]);
        colormap(terrain_ramp)

        k = colorbar;
        ylabel(k,'Slide Risk Probability (\%)','Interpreter','Latex','FontSize',12)
        xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
        ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
        zlabel ('Slide Risk Probability (\%)','Interpreter','Latex','FontSize',12)
        set(gca,'FontName','Garamond')
        box on

        drawnow
        % Capture the plot as an image
        frame = getframe(h);
        im = frame2im(frame);
        [imind,cm] = rgb2ind(im,256);
        % Write to the GIF File
        if t == 1
            imwrite(imind,cm,FileName,'gif', 'Loopcount',inf);
        else
            imwrite(imind,cm,FileName,'gif','WriteMode','append');
        end
    end
    clf
    close all
end
%% Pollutant Concentration
if flags.flag_waterquality == 1
    % Adjusting the size
    h = figure;
    axis tight manual % this ensures that getframe() returns a consistent size
    FileName_String = 'Pollutant_Concentration.gif';
    FileName = fullfile(folderName,strcat('\',FileName_String));
    set(gcf,'units','inches','position',[3,3,6.5,5])

    % Replace all infs for nan
    z = Maps.WQ_States.Pol_Conc_Map; % Plotting concentration
    z(idx_nan) = nan;
    z(z<LULC_Properties.Pol_min) = nan;
    if ~isnan(max(max(max(z))))
        for t = 1:f:length(running_control.time_records)
            t_title = running_control.time_records(t);
            % Draw plot for d = x.^n
            zmax = max(max(z(:,:,t)));
            zmin = min(min(z(:,:,t)));
            zmax = max(zmax,0);
            zmin = max(zmin,0);
            if zmax == 0 || zmin == zmax
                zmin = min(min(min(z)));
                zmax = max(max(max(z)));
            end
            z(idx_nan) = nan;
            F = z([ybegin:1:yend],[xbegin:1:xend],t);
            surf(x_grid,y_grid,F);
            axis([min(min(x_grid)) max(max(x_grid)) min(min(y_grid)) max(max(y_grid)) zmin zmax])

            shading INTERP;
            if flags.flag_elapsed_time == 1
                title(sprintf('Time(h) = %4.2f',t_title/60),'Interpreter','Latex','FontSize',12)
            else
                title(sprintf(string(t_title)),'Interpreter','Latex','FontSize',12);
            end
            view(0,90);
            colorbar
            caxis([zmin zmax]);
            colormap(linspecer)

            k = colorbar;
            ylabel(k,'Concentration (mg/L)','Interpreter','Latex','FontSize',12)
            xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
            ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
            zlabel ('Concentration (mg/L)','Interpreter','Latex','FontSize',12)
            set(gca,'FontName','Garamond')
            box on

            drawnow
            % Capture the plot as an image
            frame = getframe(h);
            im = frame2im(frame);
            [imind,cm] = rgb2ind(im,256);
            % Write to the GIF File
            if t == 1
                imwrite(imind,cm,FileName,'gif', 'Loopcount',inf);
            else
                imwrite(imind,cm,FileName,'gif','WriteMode','append');
            end
        end
    end
    clf
    close all

    %% Pollutant Mass
    % Adjusting the size
    h = figure;
    axis tight manual % this ensures that getframe() returns a consistent size
    FileName_String = 'Mass_of_pollutant.gif';
    FileName = fullfile(folderName,strcat('\',FileName_String));
    set(gcf,'units','inches','position',[3,3,6.5,5])
    % Replace all infs for nan
    z = Maps.WQ_States.Pol_mass_map/Wshed_Properties.cell_area*1000; % Plotting pollutant mass in grams
    z = log(z);
    z(isinf(z)) = nan;
    zmax = max(max(max(z)));
    zmin = min(min(min(z)));
    for t = 1:f:length(running_control.time_records)
        t_title = running_control.time_records(t);
        % Draw plot for d = x.^n
        LULC_Properties.Pol_min = 0.01; % g/m2
        z(z<=LULC_Properties.Pol_min)=nan;
        F = z([ybegin:1:yend],[xbegin:1:xend],t);
        surf(x_grid,y_grid,F);
        axis tight
        shading INTERP;
        if flags.flag_elapsed_time == 1
            title(sprintf('Time(h) = %4.2f',t_title/60),'Interpreter','Latex','FontSize',12)
        else
            title(sprintf(string(t_title)),'Interpreter','Latex','FontSize',12);
        end
        view(0,90);
        c = colorbar;
        caxis([zmin zmax]);
        colormap(terrain_ramp)
        k = colorbar;
        ylabel(k,'Log-scale Mass of pollutant ($\mathrm{g/m^2}$)','Interpreter','Latex','FontSize',12)
        xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
        ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
        zlabel ('Mass of pollutant (kg/m^2)','Interpreter','Latex','FontSize',12)
        set(gca,'FontName','Garamond')
        box on

        drawnow
        % Capture the plot as an image
        frame = getframe(h);
        im = frame2im(frame);
        [imind,cm] = rgb2ind(im,256);
        % Write to the GIF File
        if t == 1
            imwrite(imind,cm,FileName,'gif', 'Loopcount',inf);
        else
            imwrite(imind,cm,FileName,'gif','WriteMode','append');
        end
    end
end
close all