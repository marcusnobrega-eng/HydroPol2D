function [rainfall_raster] = Satellite_processing(flag_downloader, register, k)
%% Satellite data processing

% If the model is set up for off-line processing, 
% satellite data is downloaded once
if input_table{31,5} == 0 && flag_downloader == 0
    % Stablish the File Tranfer Protocol
    FTP = ftp('ftp://persiann.eng.uci.edu');
    productID = 'PDIRNow1hourly/';
    % Reading the strar and end date
    input_table_running_control = table2array(input_table(:,2));
    [s_y,s_m,s_d] = ymd(datetime(datestr(input_table_running_control(11)+datenum('30-Dec-1899'))));
    [e_y,e_m,e_d] = ymd(datetime(datestr(input_table_running_control(12)+datenum('30-Dec-1899'))));
    % extranting year month and day, then converting into strings
    s_y=num2str(s_y);s_m=num2str(s_m);s_d=num2str(s_d);
    e_y=num2str(e_y);e_m=num2str(e_m);e_d=num2str(e_d);
    if strlength(s_m)==1
        s_m=strcat('0',s_m);
    end
    if strlength(e_m)==1
        e_m=strcat('0',e_m);
    end
    if strlength(s_d)==1
        s_d=strcat('0',s_d);
    end
    if strlength(e_d)==1
        e_d=strcat('0',e_d);
    end
    
    % Changing the directoy of the FTP for the desired product required
    directory = append('CHRSdata/PDIRNow/',productID,num2str(s_y)); cd(FTP,directory);
    % Extract the directory with all data available
    list = dir(FTP); temp = {list.name};
    % Finding the index from the list of the star and end date
    star_name_founder = strcat('pdirnow1h',s_y(3:4),s_m,s_d,'00','.bin.gz');
    end_name_founder = strcat('pdirnow1h',e_y(3:4),e_m,e_d,'23','.bin.gz');
    start_name = find(ismember(temp, star_name_founder));
    end_name = find(ismember(temp, end_name_founder));
    
    % Downloading the data
    mkdir('Spatial_rainfall_data');
    for i=start_name:end_name
        mget(FTP,list(i,1).name,'Spatial_rainfall_data');
        Rainfall_data_downloaded = strcat(num2str(i/end_name*100),' %')
    end
    flag_downloader = 1;
end

if input_table{31,5} == 1
    % Create a temporal folder to storage rainfall data
    if flag_downloader==0
        mkdir('Spatial_rainfall_data');
        flag_downloader = 1;
    end
    % Stablish the File Tranfer Protocol
    FTP = ftp('ftp://persiann.eng.uci.edu');
    productID = 'PDIRNow1hourly/';
    % Reading the strar and end date
    input_table_running_control = table2array(input_table(:,2));
    [s_y,s_m,s_d] = ymd(datetime(datestr(input_table_running_control(11)+datenum('30-Dec-1899'))));
    % extranting year month and day, then converting into strings
    s_y=num2str(s_y);s_m=num2str(s_m);s_d=num2str(s_d);
    if strlength(s_m)==1
        s_m=strcat('0',s_m);
    end
    if strlength(s_d)==1
        s_d=strcat('0',s_d);
    end

    % Changing the directoy of the FTP for the desired product required
    directory = append('CHRSdata/PDIRNow/',productID,num2str(s_y)); cd(FTP,directory);
    % Extract the directory with all data available
    list = dir(FTP); temp = {list.name};
    % Finding the index from the list of the star and end date
    star_name_founder = strcat('pdirnow1h',s_y(3:4),s_m,s_d,'00','.bin.gz');
    % Reading the last file in the directory
    end_name_founder = temp(end);
    start_name = find(ismember(temp, star_name_founder));
    end_name = find(ismember(temp, end_name_founder));
    
    % Downloading the data

    for i=start_name:end_name
        mget(FTP,list(i,1).name,'Spatial_rainfall_data');
        Rainfall_data_downloaded = strcat(num2str(i/end_name*100),' %')
    end
    flag_first_download = 1;
end

    %%%%% Reading PDIR-now data for the study area %%%%%%

    % Unzip the data
    gunzip('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\pdirnow1h22092300.bin.gz');
    % Open the binary file
    fid = fopen('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\pdirnow1h22092300.bin','r'); 
    % Read the binary data with the desired format
    data = fread(fid,[9000 3000],'int16','l')';
    % close the binary file
    fclose(fid);
    % Delete the unziped file
    delete('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\pdirnow1h22092300.bin')
    % -99 data is NoData
    data(data<0) = NaN;
    % Scaled data according data provider
    data = data / 100;
    % Due to some bug about of fread() function, half of the data is
    % inverted in the horizontal axis, the invert them again.
    data= horzcat(data(:,4501:9000),data(:,1:4500));

    % Making the raster
    crs = geocrs(4326);
    % Extent and resolution definition in Degrees
    nx = 9000; ny = 3000; xmin = -180; ymax = 60; cs = 0.04;
    rasterSize = [ny nx]; worldFile = [cs 0 xmin; 0 -cs ymax];
    rasterInterpretation = 'cells';
    % Making the base matrix for the raster
    ref = georasterref(worldFile, rasterSize, rasterInterpretation);
    % Writing the geo-raster
    geotiffwrite('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\rainfall.tif', double(data), ref);
    % Reading the raster
    [rr, R] = geotiffread('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\rainfall.tif');
    % Croping the raster to the country area extent, this is to reduce
    % computational effort in future processing
    [lat,lon] = projinv(DEM_raster.georef.SpatialRef.ProjectedCRS,DEM_raster.georef.SpatialRef.XWorldLimits,DEM_raster.georef.SpatialRef.YWorldLimits);
    % Creating the extent to crop the data
   
    [rr2, rR] = geocrop(rr,R,[lat(1)-1 lat(2)+1],[lon(1)-1 lon(2)+1]);
    rr2 = rr2(end:-1:1,:);
    % Reproject the coordinates from EPSG:4326 to EPSG:3857
    crs = projcrs(3857);
    % Reprojecting the latitude and longitude
    [x, y] = projfwd(crs, rR.LatitudeLimits, rR.LongitudeLimits);
    % Average dimention of the pixel size acordding the ecuator
    % Accuracy could be affected according the latitude
    cs = deg2km(rR.CellExtentInLatitude)*1000;
    nx = rR.RasterSize(2); ny = rR.RasterSize(1);
    rasterSize = [ny nx];
    % Creating the reference for the cropped area
    ref2 = maprefcells(x, y, rasterSize);
    geotiffwrite('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\rainfall_3857.tif', double(rr2), ref2,'CoordRefSysCode',3857);
    delete('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\rainfall.tif')

    % Reading the cropped file with GRIDobj
    rr = GRIDobj('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\rainfall_3857.tif');
    % Resampling with the DEM resolution and nearest method
    rainfall_raster = resample(rr,DEM_raster.cellsize,'nearest');
    clear rr;
    delete('G:\Drives compartilhados\2DCAWQ_Model\Estudos_Completos\Honduras\PDIR_test_FTP\rainfall_3857.tif')
    rainfall_raster = crop(rainfall_raster,DEM_raster.georef.SpatialRef.XWorldLimits,DEM_raster.georef.SpatialRef.YWorldLimits);
    % to match with the reference DEM array size
    rainfall_raster = resample(rainfall_raster,DEM_raster);
    temp = DEM_raster; temp.Z = ~isnan(DEM_raster.Z);
    rainfall_raster = clip(rainfall_raster,temp);
    clear temp;

    % imagesc(resampled_rr);hold on;
    % colorbar();

    %%%%% Making a shapefile as reference for the study area %%%%%%

    % Reads the DEM as reference and create a shapefile as struct
    % [rdem, Rdem] = readgeoraster(char(table2cell((input_table(3,31)))));
    % % Creating a binary mask
    % binaryMask = ~isnan(DEM_raster.Z);
    % boundaries = bwboundaries(binaryMask);
    % % Pre-allocate arrays to store combined X and Y coordinates
    % combinedX = [];
    % combinedY = [];
    % 
    % % Combine all boundary coordinates into a single array
    % for k = 1:numel(boundaries)
    %     boundary = boundaries{k};
    %     X = boundary(:, 2);
    %     Y = boundary(:, 1);
    %     combinedX = [combinedX; X; NaN]; % Add NaN to separate polygons
    %     combinedY = [combinedY; Y; NaN]; % Add NaN to separate polygons
    % end
    % % Remove the trailing NaNs at the end (optional)
    % combinedX = combinedX(1:end-1);
    % combinedY = combinedY(1:end-1);
    % % making the geostruct to alocate the shapefile
    % S = struct('Geometry', 'Polygon', 'BoundingBox', [], 'X', [], 'Y', [], 'fid', 1, 'DN', 0);
    % S.BoundingBox = [Rdem.XWorldLimits(1,1), Rdem.YWorldLimits(1,1); Rdem.XWorldLimits(1,2), Rdem.YWorldLimits(1,2)]; % Calculate bounding box for each polygon
    % S.X = (Rdem.XWorldLimits(1)  + combinedX * Rdem.CellExtentInWorldX - Rdem.CellExtentInWorldX/2)';
    % S.Y = (Rdem.YWorldLimits(2)  - combinedY * Rdem.CellExtentInWorldY + Rdem.CellExtentInWorldY/2)';
end

