%% Comparing Model Inputs

% Model
rain_model = load('rain_original_model.mat');
rain_model = rain_model.delta_p;
input_model = load('input_data_original_model.mat');
input_model = input_model.zzz_input_maps_data;
% Solver
rain_solver = load('rain_original_solver.mat');
rain_solver = rain_solver.zzz_delta_p;
input_solver = load('input_data_original_solver.mat');
input_solver = input_solver.zzz_input_maps_data;

% Differences
rain_difference = sum(rain_model - rain_solver)

input_data_difference = nansum(nansum(nansum(input_model - input_solver)))