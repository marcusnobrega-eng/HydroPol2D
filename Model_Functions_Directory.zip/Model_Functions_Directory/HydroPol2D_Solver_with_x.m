% Running HydroPol2D and Retrieving A few States


function [Obj_fun,Qmod,Cmod,Qmod_gauges,Cmod_gauges] = HydroPol2D_Solver_with_x(x,flag_calibrate_wq	, time_observed, easting_obs_cell, northing_obs_cell, BC_States, CA_States, Courant_Parameters, date_begin, DEM_raster, depths, Elevation_Properties, flags, gauges, GIS_data, Human_Instability, Hydro_States, idx_nan, idx_nan_5, idx_outlet, Inflow_Parameters, LULC_Properties, Maps, nx_max, ny_max, outlet_index, outlet_runoff_volume, outlet_type, Rainfall_Parameters, recording_parameters, running_control, slope_outlet, Soil_Properties, steps, t_previous, time_calculation_routing, time_step, time_step_model, tmin_wq, WQ_States, Wshed_Properties)
x = x';

flag_opt_fun = 2;

% --- LULC Parameter Assigning --- %
for i = 1:n_LULC %
    % Only Roughness and h_0
    LULC_Properties.roughness(LULC_Properties.idx_lulc(:,:,i)) = x(i,1); % assigning values for roughness at impervious areas
    LULC_Properties.h_0(LULC_Properties.idx_lulc(:,:,i)) = x(i + n_LULC,1); % Initial Abstraction
end


% Calculation of Spatial Inputs
% -- Soil Parameter Assigning ---- %
Soil_Properties.ksat = zeros(size(dem)); Soil_Properties.psi = Soil_Properties.ksat; Soil_Properties.teta_s = Soil_Properties.ksat;
for i = 1:n_SOIL
    Soil_Properties.ksat(Soil_Properties.idx_soil(:,:,i)) = x(i + 6*n_LULC,1); % similar things happening below
    Soil_Properties.psi(Soil_Properties.idx_soil(:,:,i)) = x(i + 6*n_LULC + n_SOIL,1);
    Soil_Properties.teta_sat(Soil_Properties.idx_soil(:,:,i)) = x(i + 6*n_LULC + 2*n_SOIL,1);
end
Soil_Properties.teta_i = zeros(size(teta_s));

% Mask in Impervious Areas
Soil_Properties.ksat(idx_imp) = 0;

% Preallocation
LULC_Properties.C_1 = zeros(size(dem));
LULC_Properties.C_2 = zeros(size(dem));
LULC_Properties.C_3 = zeros(size(dem));
LULC_Properties.C_4  = zeros(size(dem));
%% Looping for n_events

for ii = 1:n_events
    sprintf('Event %d',ii)
    % Warmup Files - Initial Conditions
    depths.d_t = double(warmup_depths(:,:,ii));
    Soil_Properties.I_0 = double(warmup_I_0(:,:,ii));
    Soil_Properties.I_t = Soil_Properties.I_0; I_p = Soil_Properties.I_0;


    % Calculation of B_t
    if flag_calibrate_wq == 1 %
        for i = 1:n_LULC
            LULC_Properties.C_1(LULC_Properties.idx_lulc(:,:,i)) =  x(i + 2*n_LULC,1);
            LULC_Properties.C_2(LULC_Properties.idx_lulc(:,:,i)) =  x(i + 3*n_LULC,1);
            LULC_Properties.C_3(LULC_Properties.idx_lulc(:,:,i)) =  x(i + 4 *n_LULC,1);
            C_4(LULC_Properties.idx_lulc(:,:,i)) =  x(i + 5*n_LULC,1);
        end
        WQ_States.B_t = LULC_Properties.C_1.*(1 - exp(1).^(-LULC_Properties.C_2*ADD_events(ii))); % kg/ha
        WQ_States.B_t = WQ_States.B_t*Wshed_Properties.cell_area/10^4; % kg per cell      
    end    

    % Entering Observations
    n_observations = sum(~isnan(time_observed(:,ii)));
    obs_discharge = observed_flow(1:n_observations,ii);
    obs_pollutograph = pollutant_concentration(1:n_observations,ii);
    time_obs = time_observed(1:n_observations,ii);

    % Entering delta_p
    count = sum(~isnan(delta_p_obs(ii,:)));
    delta_p = delta_p_obs(ii,1:count);
    time_deltap = cumsum(ones(1,length(delta_p))*time_step_model);    
    

    % Simulation Time
    running_control.routing_time = time_obs(end,1);

    % Run HydroPol2D Routing Solver
    [Qmod, Cmod,Qmod_gauges,Cmod_gauges] = HydroPol2D_Routing_Solver(flag_calibrate_wq,time_obs	, easting_obs_cell, northing_obs_cell, BC_States, CA_States, Courant_Parameters, date_begin, DEM_raster, depths, Elevation_Properties, flags, gauges, GIS_data, Human_Instability, Hydro_States, idx_nan, idx_nan_5, idx_outlet, Inflow_Parameters, LULC_Properties, Maps, nx_max, ny_max, outlet_index, outlet_runoff_volume, outlet_type, Rainfall_Parameters, recording_parameters, running_control, slope_outlet, Soil_Properties, steps, t_previous, time_calculation_routing, time_step, time_step_model, tmin_wq, WQ_States, Wshed_Properties)

if flag_waterquality ~= 1
    if flag_opt_fun == 1 % NSE
        % Nash-Suctclife-Efficiency and Objective function
        NSE = 1 - sum((obs_discharge - Qmod).^2)/(sum((obs_discharge - mean(obs_discharge)).^2)); % We want to maximize it
        Obj_fun(ii,1) = -NSE; % Therefore, we want to minimize it
    end

    if flag_opt_fun == 2 % RMSE
        n_elements = length(obs_discharge);
        RMSE = sum((obs_discharge - Qmod).^2/n_elements);
        Obj_fun(ii,1) = RMSE; % minimize RMSE
    end

    if flag_opt_fun == 3 % R2
        r2 = corrcoef(obs_discharge,Qmod);
        Obj_fun(ii,1) = -r2(1,2); % maximize r2
    end

    if flag_opt_fun == 4 % Peak Flow
        z1 = max(obs_discharge);
        z2 = max(Qmod);
        Obj_fun(ii,1) = abs(z1 - z2); % Absolute value of peak flows
    end
else % Modelling Water Quality
    if flag_opt_fun == 1 % NSE
        % Nash-Suctclife-Efficiency and Objective function
        NSE = 1 - sum((obs_pollutograph - Cmod).^2)/(sum((obs_pollutograph - mean(obs_pollutograph)).^2)); % We want to maximize it
        Obj_fun(ii,1) = -NSE; % Therefore, we want to minimize it
    end

    if flag_opt_fun == 2 % RMSE
        n_elements = length(obs_pollutograph);
        RMSE = sqrt(sum((obs_pollutograph - Cmod).^2/n_elements));
        Obj_fun(ii,1) = RMSE; % minimize RMSE
    end

    if flag_opt_fun == 3 % R2
        r2 = corrcoef(obs_pollutograph,Cmod);
        Obj_fun(ii,1) = -r2(1,2); % maximize r2
    end

    if flag_opt_fun == 4 % Peak Flow
        z1 = max(obs_pollutograph);
        z2 = max(Cmod);
        Obj_fun(ii,1) = abs(z1 - z2); % Absolute value of peak flows
    end
end
sprintf('End of all events')
end

%% Plot a Quick Chart
% figure(2)
% if flag_waterquality ~= 1
%     for jj = 1:n_events
%         if n_events > 1
%             col = 2;
%         else
%             col = 1;
%         end        
%         subplot(n_events,col,ii);
%         plot(time_obs,Qmod,'-black','Marker','*')
%         hold on
%         plot(time_obs,obs_discharge,'--b','Marker','*')
%         xlabel('Elapsed time (min)','FontSize',12,'Interpreter','latex')
%         ylabel('Discharge ($m^3/s$)','FontSize',12,'Interpreter','latex')
%         legend('Modeled','Observed','interpreter','latex')        
%     end
% else
%     for jj = 1:n_events
%         if n_events > 1
%             col = 2;
%         else
%             col = 1;
%         end
%         subplot(n_events,col,ii);
%         plot(time_obs,Cmod,'-black','Marker','*')
%         hold on
%         plot(time_obs,obs_pollutograph,'--b','Marker','*')
%         xlabel('Elapsed time (min)','FontSize',12,'Interpreter','latex')
%         ylabel('Pollutant Concentration ($mg/L$)','FontSize',12,'Interpreter','latex')
%         legend('Modeled','Observed','interpreter','latex')
%     end
% end
% pause(0.25)
% close(2)
% Final Objective Function
Obj_fun = mean(Obj_fun);

end

