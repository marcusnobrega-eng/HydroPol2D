%% Main HydroPol2D While Loop
% Developer: Marcus Nobrega
% Date 5/21/2023
% Goal - Run the main modeling process of the model

min_soil_moisture = 5*(double(Soil_Properties.I_0>0));
min_soil_moisture(Soil_Properties.I_0==0) = 0.01;
min_soil_moisture(idx_nan) = nan;
Soil_Properties.I_0(Soil_Properties.I_0 == 0) = 0.01;
while t <= (routing_time + min_time_step/60)
    % Infiltration and Available Depth
    % Show stats
    perc____duremain______tsec_______dtmm______infmmhr____CmgL_____dtmWQ = [(t)/routing_time*100, (toc/((t)/routing_time) - toc)/3600,time_step*60,max(max(d_t(~isinf(d_t)))),max(max(C)), max(max((P_conc))), tmin_wq]
    if tmin_wq < 0 || isnan(tmin_wq) || isinf(tmin_wq)
        error('Instability')
    end
    % Inflows
    if flag_inflow == 1
        inflow = zeros(size(dem,1),size(dem,2)); % This is to solve spatially, don't delete
        for i = 1:n_stream_gauges
            inflow = inflow + delta_inflow_agg(i)*inflow_cells(:,:,i);
        end
    end

    if k == 1
        if flag_infiltration == 1
            i_a = (delta_p_agg.*rainfall_matrix + inflow + depths.d_0 - ETP/24)./(time_step/60);
            C = Soil_Properties.ksat.*(1 + ((depths.d_0 + Soil_Properties.psi).*(Soil_Properties.teta_sat - Soil_Properties.teta_i))./Soil_Properties.I_0); % matrix form            
            f = min(C,i_a);
            I_t = max(Soil_Properties.I_0 + (f)*time_step/60,Soil_Properties.I_0); % Extracting ETP from soil
            idx_ETR = I_t == min_soil_moisture;
            ETR = ETP;
            ETR(idx_ETR) = ETP(idx_ETR) - (min_soil_moisture(idx_ETR) - (Soil_Properties.I_0(idx_ETR) + (f(idx_ETR))*time_step/60));            
            pef = delta_p_agg.*rainfall_matrix + inflow - f*time_step/60;
            d_t = depths.d_0 + pef;
            T = Soil_Properties.Tr; % Beginning to track the replenishing time
        else
            %i_a = (delta_p_agg*rainfall_matrix + delta_inflow_agg*inflow_cells + depths.d_0)./(time_step/60);
            pef = delta_p_agg.*rainfall_matrix + inflow;
            d_t = depths.d_0 + pef;
        end
    else
        if flag_infiltration == 1
            % Effective precipitation - Green-Ampt(1911)
            i_a = (delta_p_agg.*rainfall_matrix + inflow + d_p - ETP/24)./(time_step/60);
            C = Soil_Properties.ksat.*(1 + ((d_p + Soil_Properties.psi).*(Soil_Properties.teta_sat - Soil_Properties.teta_i))./I_p); % matrix form
            idx_C = (i_a <= C); % Values where i_a is below C
            idx_i_a = (i_a > C); % Values where i_a is larger than C
            T = T - time_step/60/60; % Recoverying time (hours)
            T(idx_i_a) = Soil_Properties.Tr(idx_i_a); % Saturated Areas we begin the process again
            idx_T = T < 0; % Cells where the replenishing time is reached            
            f = min(C,i_a); % Infiltration rate (mm/hr)
            I_t = max(I_p + f*time_step/60 - Soil_Properties.k_out.*double(idx_C)*time_step/60,min_soil_moisture);
            idx_ETR = I_t == min_soil_moisture; 
            ETR = ETP;
            ETR(idx_ETR) = ETP(idx_ETR) - (min_soil_moisture(idx_ETR) - (I_p(idx_ETR) + f(idx_ETR)*time_step/60 - Soil_Properties.k_out(idx_ETR)*time_step/60));
            % Refreshing I_t to Soil_Properties.I_0 for cases where idx_T > 0
            I_t(idx_T) = min_soil_moisture(idx_T);
            pef = delta_p_agg.*rainfall_matrix + inflow - f*time_step/60;
            d_t = d_p + pef; %% ATTENTION HERE
        else
            i_a = (delta_p_agg.*rainfall_matrix + inflow + d_p - ETP/24)./(time_step/60);
            pef = delta_p_agg.*rainfall_matrix + inflow - ETP/24;
            d_t = d_p + pef;
        end
    end
    d_tot = d_t;

    %%%% WATER DEPTHS %%%
    depths.d_left_cell = [zeros(ny_max,1),d_tot(:,1:(nx_max-1))];
    depths.depths.d_right_cell = [d_tot(:,(2:(nx_max))) zeros(ny_max,1)];
    depths.depths.d_up_cell = [zeros(1,nx_max) ; d_tot(1:(ny_max-1),:)];
    depths.d_down_cell = [d_tot(2:(ny_max),:) ; zeros(1,nx_max)];
    if flag_D8 == 1
        % Simulate with D-8 flow direction
        % --- Adding NE, SE, SW, NW --- %
        zero_matrix = NaN(size(spatial_domain));
        elevation_NE_t = zero_matrix; elevation_SE_t = zero_matrix;
        elevation_SW_t = zero_matrix; elevation_NW_t = zero_matrix;
        d_NE_t = zero_matrix; d_SE_t = zero_matrix; d_SW_t = zero_matrix; d_NW_t = zero_matrix;

        elevation_NE_t(2:(ny_max),1:(nx_max-1)) = elevation(1:(ny_max-1),2:nx_max); % OK
        elevation_SE_t(1:(ny_max-1),1:(nx_max-1)) = elevation(2:ny_max,2:nx_max); % OK
        elevation_SW_t(1:(ny_max-1),2:(nx_max)) = elevation(2:(ny_max),1:(nx_max-1)); % OK
        elevation_NW_t(2:ny_max,2:nx_max) = elevation(1:(ny_max-1),1:(nx_max-1)); % OK

        d_NE_t(2:(ny_max),1:(nx_max-1)) = d_tot(1:(ny_max-1),2:nx_max); % OK
        d_SE_t(1:(ny_max-1),1:(nx_max-1)) = d_tot(2:ny_max,2:nx_max); % OK
        d_SW_t(1:(ny_max-1),2:(nx_max)) = d_tot(2:(ny_max),1:(nx_max-1)); % OK
        d_NW_t(2:ny_max,2:nx_max) = d_tot(1:(ny_max-1),1:(nx_max-1)); % OK    
    else
        % Simulate with D-4 flow direction
        % Everything already calculated
    end
    %  Flood routing for each cell
    % Check if Nan or Inf occured in d_t
    if max(max(isinf(d_t))) == 1
        ttt = 1;
    end
    if flag_D8 == 1 % D-8 C-A Model
        [outflow_rate.qout_left_t,outflow_rate.qout_right_t,outflow_rate.qout_up_t,outflow_rate.qout_down_t,outlet_flow,qout_ne_t,qout_se_t,qout_sw_t,qout_nw_t,d_t,I_tot_end_cell,I_cell] = CA_Routing_8D(Elevation_Properties.elevation_cell,Elevation_Properties.elevation_left_t,Elevation_Properties.elevation_right_t,Elevation_Properties.elevation_up_t,Elevation_Properties.elevation_down_t,d_tot,depths.d_left_cell,depths.d_right_cell,depths.d_up_cell,depths.d_down_cell,LULC_Properties.roughness,cell_area,time_step,LULC_Properties.h_0,Resolution,I_tot_end_cell,outlet_index,outlet_type,slope_outlet,row_outlet,col_outlet,idx_nan,flag_critical,elevation_NE_t, elevation_SE_t, elevation_SW_t, elevation_NW_t, d_NE_t, d_SE_t, d_SW_t, d_NW_t);
    else % 4-D CA Model
        [outflow_rate.qout_left_t,outflow_rate.qout_right_t,outflow_rate.qout_up_t,outflow_rate.qout_down_t,outlet_flow,d_t,I_tot_end_cell,I_cell] = CA_Routing(Elevation_Properties.elevation_cell,Elevation_Properties.elevation_left_t,Elevation_Properties.elevation_right_t,Elevation_Properties.elevation_up_t,Elevation_Properties.elevation_down_t,d_tot,depths.d_left_cell,depths.d_right_cell,depths.d_up_cell,depths.d_down_cell,LULC_Properties.roughness,cell_area,time_step,LULC_Properties.h_0,Resolution,I_tot_end_cell,outlet_index,outlet_type,slope_outlet,row_outlet,col_outlet,idx_nan,flag_critical);
    end
    
%     qout_t = qout_left + qout_right + qout_up + qout_down + qout_ne + qout_se + qout_sw + qout_ne;
    % Inflows - Von-Neuman
    outflow_rate.qin_left_t = [zeros(ny_max,1),outflow_rate.qout_right_t(:,1:(nx_max-1))];
    outflow_rate.qin_right_t = [outflow_rate.qout_left_t(:,(2:(nx_max))) zeros(ny_max,1)];
    outflow_rate.qin_up_t = [zeros(1,nx_max) ; outflow_rate.qout_down_t(1:(ny_max-1),:)];
    outflow_rate.qin_down_t = [outflow_rate.qout_up_t(2:(ny_max),:) ; zeros(1,nx_max)];
    % Inflows - Inclined Directions
    if flag_D8 == 1
        zero_matrix = zeros(size(spatial_domain));
        outflow_rate.qin_ne_t = zero_matrix; outflow_rate.qin_se_t = zero_matrix; outflow_rate.qin_sw_t = zero_matrix; outflow_rate.qin_nw_t = zero_matrix;
        outflow_rate.qin_ne_t(2:(ny_max),1:(nx_max-1)) = qout_sw_t(1:(ny_max-1),2:(nx_max)); % OK
        outflow_rate.qin_se_t(1:(ny_max-1),1:(nx_max-1)) = qout_nw_t(2:ny_max,2:nx_max); % OK
        outflow_rate.qin_sw_t(1:(ny_max-1),2:(nx_max)) = qout_ne_t(2:(ny_max),1:(nx_max-1)); % OK
        outflow_rate.qin_nw_t(2:ny_max,2:nx_max) = qout_se_t(1:(ny_max-1),1:(nx_max-1)); % OK
    end
    if flag_D8 == 1
        outflow_rate.qin_t = outflow_rate.qin_left_t + outflow_rate.qin_right_t + outflow_rate.qin_up_t + outflow_rate.qin_down_t + outflow_rate.qin_ne_t + outflow_rate.qin_se_t + outflow_rate.qin_sw_t + outflow_rate.qin_nw_t;
        %         qin_t = qin_left_t + qin_right_t + qin_up_t + qin_down_t;    
    else
        outflow_rate.qin_t = outflow_rate.qin_left_t + outflow_rate.qin_right_t + outflow_rate.qin_up_t + outflow_rate.qin_down_t;
    end
    idx = outflow_rate.qin_t > flow_tolerance;
    idx2 = outflow_rate.qin_t <= flow_tolerance;
    idx3 = logical(isnan(outflow_rate.qin_t) + isinf(outflow_rate.qin_t));
    outflow_rate.qin_t(idx3) = 0;

    % Water Quality Parameters for f(B(t))    
    if flag_waterquality == 1
        if flag_D8 ~= 1
            [B_t,P_conc,Out_Conc,tmin_wq,tot_W_out,mass_lost,Tot_Washed] = build_up_wash_off(LULC_Properties.C_3,LULC_Properties.C_4,outflow_rate.qout_left_t,outflow_rate.qout_right_t,outflow_rate.qout_up_t,outflow_rate.qout_down_t,outlet_flow,B_t,time_step,nx_max,ny_max,cell_area,outlet_index,idx_nan_5,flag_wq_model,mass_lost,Tot_Washed,Bmin,Bmax,min_Bt);
        else
            [B_t,P_conc,Out_Conc,tmin_wq,tot_W_out,mass_lost,Tot_Washed] = build_up_wash_off_8D(LULC_Properties.C_3,LULC_Properties.C_4,outflow_rate.qout_left_t,outflow_rate.qout_right_t,outflow_rate.qout_up_t,outflow_rate.qout_down_t,outlet_flow,qout_ne_t,qout_se_t,qout_sw_t,qout_nw_t,B_t,time_step,nx_max,ny_max,cell_area,outlet_index,idx_nan_5,flag_wq_model,mass_lost,Tot_Washed,Bmin,Bmax,min_Bt);
        end
    end
    %%%% Checking Mass Balance
    if flag_waterquality == 1
        if sum(sum(B_t(~isinf(B_t)))) > 1.2*initial_mass  % More than 5%
            error('Brutal instability in B(t). More than 20% difference')
        end
    end
    % New Time-step Calculation
    pos_save = find(time_change_records < t,1,'last');
    time_save = time_change_records(pos_save); % min
    delta_time_save = time_save - time_save_previous;
    time_save_previous = time_save;
    actual_record_timestep = find(time_change_records < t,1,'last');
    if delta_time_save > 0 || k == 1 % First time-step
        if flag_timestep == 0
            %%% SOLUTION FOR COURANT METHOD %%%
            depths.d_left_cell = [zeros(ny_max,1),d_t(:,1:(nx_max-1))];
            depths.d_right_cell = [d_t(:,(2:(nx_max))) zeros(ny_max,1)];
            depths.d_up_cell = [zeros(1,nx_max) ; d_t(1:(ny_max-1),:)];%
            depths.d_down_cell = [d_t(2:(ny_max),:) ; zeros(1,nx_max)];
            if flag_D8 == 1
                d_NE_cell = zero_matrix; d_SE_cell = zero_matrix; d_SW_cell = zero_matrix; d_NW_cell = zero_matrix;
                d_NE_cell(2:(ny_max),1:(nx_max-1)) = d_t(1:(ny_max-1),2:nx_max); % OK
                d_SE_cell(1:(ny_max-1),1:(nx_max-1)) = d_t(2:ny_max,2:nx_max); % OK
                d_SW_cell(1:(ny_max-1),2:(nx_max)) = d_t(2:(ny_max),1:(nx_max-1)); % OK
                d_NW_cell(2:ny_max,2:nx_max) = d_t(1:(ny_max-1),1:(nx_max-1)); % OK
            end
            % Considering Velocity as Celerity
%             vel_left = (I_cell(:,:,1)./(0.5/1000.*(d_t + depths.d_left_cell).*Resolution))/(time_step*60) + sqrt(9.81*(d_t + depths.d_left_cell)/2/1000); % m/s
%             vel_right = (I_cell(:,:,2)./(0.5/1000.*(d_t + depths.d_right_cell).*Resolution))/(time_step*60) + sqrt(9.81*(d_t + depths.d_right_cell)/2/1000);
%             vel_up = (I_cell(:,:,3)./(0.5/1000.*(d_t + depths.d_up_cell).*Resolution))/(time_step*60) + sqrt(9.81*(d_t + depths.d_up_cell)/2/1000); % m/s;;
%             vel_down = (I_cell(:,:,4)./(0.5/1000.*(d_t + depths.d_down_cell).*Resolution))/(time_step*60) + sqrt(9.81*(d_t + depths.d_down_cell)/2/1000); % m/s;
 
            % Using CA Velocities
%             vel_left = (outflow_rate.qout_left_t/1000/3600); % m/s
%             vel_right = (outflow_rate.qout_right_t/1000/3600); % m/s 
%             vel_up = (outflow_rate.qout_up_t/1000/3600); % m/s  
%             vel_down = (outflow_rate.qout_down_t/1000/3600); % m/s  

            z = d_t;
            dt_threshold = 0.05; % mm
            z(d_t < dt_threshold) = 1e12;
            velocities.vel_left = (outflow_rate.qout_left_t/1000/3600)*Resolution^2./(Resolution*z/1000); % m/s
            velocities.vel_right = (outflow_rate.qout_right_t/1000/3600)*Resolution^2./(Resolution*z/1000); % m/s 
            velocities.vel_up = (outflow_rate.qout_up_t/1000/3600)*Resolution^2./(Resolution*z/1000); % m/s  
            velocities.vel_down = (outflow_rate.qout_down_t/1000/3600)*Resolution^2./(Resolution*z/1000); % m/s  
            
            if flag_D8 == 1
%                 velocities.vel_ne = (I_cell(:,:,6)./(0.5/1000.*(d_t + d_NE_cell).*Resolution))/(time_step*60) + sqrt(9.81*(d_t + d_NE_cell)/2/1000); % m/s
%                 velocities.vel_se = (I_cell(:,:,7)./(0.5/1000.*(d_t + d_SE_cell).*Resolution))/(time_step*60) + sqrt(9.81*(d_t + d_SE_cell)/2/1000);
%                 velocities.vel_sw = (I_cell(:,:,8)./(0.5/1000.*(d_t + d_SW_cell).*Resolution))/(time_step*60) + sqrt(9.81*(d_t + d_SW_cell)/2/1000); % m/s;;
%                 velocities.vel_nw = (I_cell(:,:,9)./(0.5/1000.*(d_t + d_NW_cell).*Resolution))/(time_step*60) + sqrt(9.81*(d_t + d_NW_cell)/2/1000); % m/s;                
                velocities.vel_ne = (qout_ne_t/1000/3600); % m/s
                velocities.vel_se = (qout_se_t/1000/3600); % m/s
                velocities.vel_sw = (qout_sw_t/1000/3600); % m/s
                velocities.vel_nw = (qout_nw_t/1000/3600); % m/s
            end
            %%%%%%%%%%%%%% Find the Maximum Velocity
            max_velocity_left = max(max(velocities.vel_left));
            max_velocity_right = max(max(velocities.vel_right));
            max_velocity_up = max(max(velocities.vel_up));
            max_velocity_down = max(max(velocities.vel_down));
            if flag_D8 == 1
                max_velocity_ne = max(max(velocities.vel_ne));
                max_velocity_se = max(max(velocities.vel_se));
                max_velocity_sw = max(max(velocities.vel_sw));
                max_velocity_nw = max(max(velocities.vel_nw));                
            end
            % - Velocit Raster - %
            %%% Maximum of All of Them %%%
            velocity_raster = max(velocities.vel_left,velocities.vel_right);
            velocity_raster = max(velocity_raster,velocities.vel_up);
            velocity_raster = max(velocity_raster,velocities.vel_down);
            if flag_D8 == 1
                velocity_raster = max(velocity_raster,velocities.vel_ne);
                velocity_raster = max(velocity_raster,velocities.vel_se);
                velocity_raster = max(velocity_raster,velocities.vel_sw);
                velocity_raster = max(velocity_raster,velocities.vel_nw);    
                velocity_vector = [max_velocity_left, max_velocity_right, max_velocity_up, max_velocity_down, max_velocity_ne, max_velocity_se, max_velocity_sw, max_velocity_nw];
            else
                velocity_vector = [max_velocity_left, max_velocity_right, max_velocity_up, max_velocity_down];
            end
         
            max_velocity = max(velocity_vector);             
            if flag_D8 == 1
                factor_grid = sqrt(1/2);
            else
                factor_grid = 1;
            end
            if max_velocity == 0
                new_timestep = max_time_step;
            else
                new_timestep = (factor_grid*Resolution/max_velocity); % seconds      
            end
            time_step_factor = max(alfa_max - slope_alfa*(max(max_velocity - v_threshold,0)),alfa_min);
            alfa_save(pos_save,1) = time_step_factor;
            new_timestep = new_timestep*alfa_save(pos_save,1);

            % ---- Calculation of Stability --- %
            F_person = weight_person*gravity; % N
            % Buyoance
            F_buoy = (width1_person*width2_person)*d_t/1000*ro_water*gravity; % N
            % Available Friction
            available_friction = mu*(max(F_person - F_buoy,0));
            % Hydrodynamic Force
            hydro_force = max(1/2*(Cd*width1_person*d_t/1000.*velocity_raster.^2),0);
            % Risk Factor
            risk_t = min(hydro_force./available_friction,1);
            risk_t(idx_nan) = nan;
        else             % % % % % % % %  Solution for the Stable Method - Time-step refreshment
            % Water Slopes Calculation (THERE IS A MISTAKE HERE)
            error('This method is currenly not working, please choose the courant method')
%             wse_cell = elevation_cell + d_t_cell/1000;
%             slope(:,:,1) = 1/Resolution*(wse_cell - Elevation_Properties.elevation_left_t - depths.d_left_cell/1000);
%             slope(:,:,2) = 1/Resolution*(wse_cell - Elevation_Properties.elevation_right_t - d_right_cell/1000);
%             slope(:,:,3) = 1/Resolution*(wse_cell - Elevation_Properties.elevation_up_t - depths.d_up_cell/1000);
%             slope(:,:,4) = 1/Resolution*(wse_cell - Elevation_Properties.elevation_down_t - depths.d_down_cell/1000);
%             slope_cell = max(min(slope,[],3),slope_min); % Minimum assumed slope
%             time_step_cell = max((Resolution^2/4)*(2*LULC_Properties.roughness./((d_t_cell/1000).^(5/3)).*sqrt(slope_cell)),min_time_step);
%             time_step_cell(idx_nan_5(:,:,1)) = inf;
%             new_timestep = min(min((time_step_cell)));
        end
        if flag_waterquality == 1
            % Adding Water Quality Minimum Time-step
            alfa_wq = 1; % Reduction factor of water quality
            new_timestep = min(alfa_wq*tmin_wq,new_timestep);
        end
        % Rounding time-step to min_timestep or max_timestep with the required
        % precision. This is not very interesting, maybe we should delete
        % it
        time_calculation_routing(k,1) = new_timestep;
        time_calculation_routing(k,1) = max(time_step_increments*floor(time_calculation_routing(k,1)/time_step_increments),min_time_step);
        time_calculation_routing(k,1) = min(time_calculation_routing(k,1),max_time_step);
        time_step = time_calculation_routing(k,1)/60; % new time-step for the next run
        if time_calculation_routing(k,1) == min_time_step % Check if we reached the minimum time-step
            unstable = 1; % If this is 1, it means we possibly had an unstable period at least
        end
    elseif  k == 1
        time_calculation_routing(k,1) = time_step*60; % sec
    else
        time_calculation_routing(k,1) = time_calculation_routing(k-1,1);
    end
    max_velocity_previous = max_velocity; % Assigning right velocities
    % Agregating Inflows to the New Time-step
    if flag_inflow > 0
        for z = 1:n_stream_gauges
            z1 = find(time_deltainflow(z,:) > t_previous,1,'first'); % begin of the time-step
            z2 = find(time_deltainflow(z,:) <= t,1,'last'); % end of the time-step
            if isempty(z1)
                z1 = 1;
            end
            if isempty(z2) || z2 < z1  
                z2 = z1;
            end
            if time_step >= time_step_model
                delta_inflow_agg(z,1) = mean(delta_inflow(z,z1:z2))/(time_step_model*60)*time_step*60;
            else
                delta_inflow_agg(z,1) = delta_inflow(z,z1)/(time_step_model*60)*time_step*60;
            end
        end
    end
    % Agregating Precipitation to the New Time-step
    if flag_rainfall > 0
        if flag_spatial_rainfall ~= 1
            z1 = find(time_deltap > t_previous,1,'first'); % begin of the time-step
            z2 = find(time_deltap <= t,1,'last'); % end of the time-step
            if z2 < z1
                z2 = z1;
            end
            if time_step >= time_step_model
                delta_p_agg = mean(delta_p(1,z1:z2))/(time_step_model*60)*time_step*60;
            else
                delta_p_agg = delta_p(1,z1)/(time_step_model*60)*time_step*60;
            end
            if isnan(delta_p_agg)
                ttt = 1;
            end
        else
            % Spatial Rainfall
            % Code for Spatial-Varying Rainfall
            z1 = find(rainfall_spatial_duration <= t_previous,1,'last');
            z2 = find(rainfall_spatial_duration <= t,1,'last');
            if z1 ~= z2 || z2 == length(rainfall_spatial_duration)
                x_coordinate = coordinates(1:n_raingauges,1); % Coordinates (easting) of each rain gauge
                y_coordinate = coordinates(1:n_raingauges,2); % Coordinates (northing) of each rain gauge
                x_grid = xulcorner + Resolution*[1:1:size(DEM_raster.Z,2)]'; % Pixel easting coordinates
                y_grid = yulcorner - Resolution*[1:1:size(DEM_raster.Z,1)]'; % Pixel northing coordinates

                % Spatial Rainfall
                    if z2 == length(rainfall_spatial_duration)
                        spatial_rainfall = zeros(size(dem,1),size(dem,2));
                        
                    else
                        rainfall = rainfall_raingauges(z2,1:n_raingauges)'; % Values of rainfall at t for each rain gauge
                        idx_rainfall = isnan(rainfall);
                        rainfall(idx_rainfall) = []; % Taking out nans
                        x_coordinate(idx_rainfall) = []; % Taking out nans
                        y_coordinate(idx_rainfall) = []; % Taking out nans                        
                        [spatial_rainfall] = Rainfall_Interpolator(x_coordinate,y_coordinate,rainfall,x_grid,y_grid); % Interpolated Values
                        spatial_rainfall(idx_nan) = nan;
                        if nansum(nansum(spatial_rainfall)) > 0
                            ttt = 1
                        end
                    end
                    delta_p_agg = spatial_rainfall/3600*time_step_model*60; % Matrix of delta P for each pixel
                    spatial_rainfall_maps(:,:,z2) = spatial_rainfall;
                    average_spatial_rainfall(z2,1) = mean(spatial_rainfall(spatial_rainfall>=0));
            end      
        end
    end

    % Aggregating ETP for next time-step

            if flag_ETP == 1    
                z1 = find(climatologic_spatial_duration <= t_previous,1,'last');
                z2 = find(climatologic_spatial_duration <= t,1,'last');
                if isempty(z1) && isempty(z2) 
                    % No data, No ETP.
                    ETP = zeros(size(dem));  
                else
                    if ~isempty(z1) && z1 == z2 && z2 == length(climatologic_spatial_duration)
                        % Outside of ETP data maximum duration
                       ETP = zeros(size(dem));   
                       ETP_save(:,:,z2) = ETP; % Saving ETP Maps
                       ETR_save(:,:,z2) = ETR;
                    elseif  (isempty(z1) && z2 > 0) || z2 > z1 && z2 < length(climatologic_spatial_duration) 
                        day_of_year = day(time_ETP(z2,1),'dayofyear');   
                        [ETP] = ETP_model(z2,day_of_year,coordinates_stations(:,1),coordinates_stations(:,2),x_grid',y_grid',maxtemp_stations,mintemp_stations,avgtemp_stations,u2_stations,ur_stations,G_stations,DEM_etp,lat,Krs,alfa_albedo_input,idx_nan);
                        if nansum(nansum(ETP)) == 0
                           ETP = ETP_save(:,:,z2-1);
                           ETR = ETR_save(:,:,z2-1);
                           if nansum(nansum(ETP)) == 0
                               warning('No ETP and ETR data. Assuming it equals 0')
                               ETP = zeros(size(DEM));
                               ETP(idx_nan) = nan;
                               ETR = zeros(size(DEM));
                               ETR(idx_nan) = nan;  
                           end
                        end
                        ETP_save(:,:,z2) = ETP; % Saving ETP Maps
                        ETR_save(:,:,z2) = ETR;
                    elseif z1 == 1 && z2 == 1 && k == 1
                        % First data. We assume a constant ETP using
                        % 1st data
                        day_of_year = day(time_ETP(z2,1),'dayofyear');                    
                        [ETP] = ETP_model(z2,day_of_year,coordinates_stations(:,1),coordinates_stations(:,2),x_grid',y_grid',maxtemp_stations,mintemp_stations,avgtemp_stations,u2_stations,ur_stations,G_stations,DEM_etp,lat,Krs,alfa_albedo_input,idx_nan);
                        if nansum(nansum(ETP)) == 0
                           ETP = ETP_save(:,:,z2-1);
                           ETR = ETR_save(:,:,z2-1);
                        end                        
                        ETP_save(:,:,z2) = ETP; % Saving ETP Maps 
                        ETR_save(:,:,z2) = ETR;
                    end        
                end
            end

    % Previous Time-step
        if k == 1
            t_previous = time_calculation_routing(k,1)/60;
            t_previous_date = date_begin + time_calculation_routing(k,1)/60/60/24; % Datetime
        else
            t_previous = t; 
            t_previous_date = t_previous_date + t/60/24; % Datetime
        end

    % Inflows and Depth Refreshments
    d_t = d_t + outflow_rate.qin_t*time_step/60;
    % Clearing stored values
    outflow_rate.qout_left_t = zeros(ny_max,nx_max);
    outflow_rate.qout_right_t = zeros(ny_max,nx_max);
    outflow_rate.qout_up_t = zeros(ny_max,nx_max);
    outflow_rate.qout_down_t = zeros(ny_max,nx_max);
    outflow_rate.qout_ne_t = zeros(ny_max,nx_max);
    outflow_rate.qout_se_t = zeros(ny_max,nx_max);
    outflow_rate.qout_sw_t = zeros(ny_max,nx_max);
    outflow_rate.qout_nw_t = zeros(ny_max,nx_max);
    outflow_rate.qin_t = zeros(ny_max,nx_max);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Checking Water Balance and Saving State Variables %%%%
    % FIX IT!!!
    if flag_waterbalance  == 1
        n_rain_cells = sum(sum(idx_not_nan));
        if k == 1
            storage_begin = sum(sum(cell_area/1000.*depths.d_0(idx_not_nan))); % m3
        else
            storage_begin = storage_depth;
        end
        inflows = delta_inflow_agg/1000*n_inlets*cell_area + delta_p_agg/1000*(n_rain_cells)*cell_area;
        outflows = sum(sum(outlet_flow))/1000/3600*cell_area*time_step/60 + sum(sum((I_t(idx_not_nan) - I_p(idx_not_nan))/1000*cell_area));
        delta_flows = inflows - outflows ; % m3
        storage_depth = sum(sum(cell_area/1000.*d_t(idx_not_nan)));
        delta_storage = storage_depth - storage_begin;
        relative_vol_error(k) = 1 - delta_flows/delta_storage;
        extra_depth = (delta_flows - delta_storage)/((sum(sum(idx_not_nan)))*cell_area)*1000;
        d_t = d_t + idx_not_nan*extra_depth;

        % Water Balance Error
        relative_vol_error(k) = 1 - delta_flows/delta_storage;
    end
    % Saving Plotting Values - Recording Time
    % Maps of Flood Depths, WSE and Pollutant Concentrations
    % --- Calculating EMC --- %
    mass_outlet = max(mass_outlet + Out_Conc*((nansum(nansum(outlet_flow)/1000/3600*1000)))*(time_step*60),0); % mg
    vol_outlet = max((nansum(nansum(outlet_flow))/1000/3600*1000)*(time_step*60) + vol_outlet,0);
    % --- Calculating M(V) Curve --- %
    t_save = t + time_calculation_routing(k,1)/60;
    actual_record_state = find(time_records < t_save,1,'last');
    delta_record = actual_record_state - last_record_maps;
    last_record_maps = actual_record_state;
    if k == 1
        d(:,:,1) = d_t;
        risk(:,:,1) = risk_t;
        if flag_waterquality(1,1) == 1
            Pol_Conc_Map(:,:,1) = P_conc;
            Pol_mass_map(:,:,1) = B_t;
            EMC_outlet(1,1) = mass_outlet/vol_outlet; % mg/L
            mass_outlet_save(1,1) = mass_outlet;
            vol_outlet_save(1,1) = vol_outlet;
        end
    elseif delta_record > 0
        t_store = actual_record_state;
        d(:,:,t_store) = d_t;
        risk(:,:,t_store) = risk_t;
        if flag_waterquality == 1
            Pol_Conc_Map(:,:,t_store) = P_conc;
            Pol_mass_map(:,:,t_store) = B_t;
            EMC_outlet(t_store,1) = mass_outlet/vol_outlet; % mg/L
            mass_outlet_save(t_store,1) = mass_outlet;
            vol_outlet_save(t_store,1) = vol_outlet;
        end
    end % Calls the sub
    % Hydrographs
    actual_record_hydrograph = find(time_record_hydrograph <= t_save,1,'last');
    delta_record_hydrograph = actual_record_hydrograph - last_record_hydrograph;
    last_record_hydrograph = actual_record_hydrograph;

    if k == 1
        outet_hydrograph(1,1) = nansum(nansum(outlet_flow))/1000*cell_area/3600; % m3/s
        time_hydrograph(1,1) = time_calculation_routing(k,1)/60;
        depth_outlet(1,1) = mean(d_t(idx_outlet));
        % Saving Data of Input Gauges
        if flag_obs_gauges == 1
            for i = 1:num_obs_gauges
                x_cell = easting_obs_gauges(i); y_cell = northing_obs_gauges(i);
                wse_cell(1,i) = d_t(y_cell,x_cell)/1000 + elevation(y_cell,x_cell); % m
                depth_cell(1,i) = d_t(y_cell,x_cell)/1000; % m
                hydrograph_cell(1,i) = I_tot_end_cell(y_cell,x_cell)/(time_calculation_routing(k)); % m3/s                
            end
        end
        if flag_waterquality == 1
            outet_pollutograph(1,1) = Out_Conc; % Already averaged for all outlet cells
        end
    elseif delta_record_hydrograph > 0
        t_store = actual_record_hydrograph;
        outet_hydrograph(t_store,1) = nansum(nansum(outlet_flow))/1000*cell_area/3600; % m3/s
        time_hydrograph(t_store,1) = t;
        depth_outlet(t_store,1) = mean(d_t(idx_outlet));
        if flag_obs_gauges == 1
            % Saving Data of Input Gauges
            for i = 1:num_obs_gauges
                x_cell = easting_obs_gauges(i); y_cell = northing_obs_gauges(i);
                wse_cell(t_store,i)= d_t(y_cell,x_cell)/1000 + elevation(y_cell,x_cell); % m
                depth_cell(t_store,i) = d_t(y_cell,x_cell)/1000; % m
                hydrograph_cell(t_store,i) = I_tot_end_cell(y_cell,x_cell)/(time_calculation_routing(k)); % m3/s
            end
        end
        
        if flag_waterquality == 1
            outet_pollutograph(t_store,1) = Out_Conc;
            % Saving Data of Input Gauges
            if flag_obs_gauges == 1
                for i = 1:num_obs_gauges
                    x_cell = easting_obs_gauges(i); y_cell = northing_obs_gauges(i);
                    pollutograph_cell(t_store,i)= P_conc(y_cell,x_cell); % mg/L
                end      
            end
        end
    end % Calls the sub
    % Saving Maximum Depths and Outlet Flows
    if k == 1
        dmax_final = d_t;
        vmax_final = velocity_raster;
    else
        dmax_final = max(d_t,dmax_final);
        vmax_final = max(velocity_raster,vmax_final);
    end
    outlet_runoff_volume = nansum(nansum(outlet_flow))*time_step/60*cell_area/drainage_area + outlet_runoff_volume; % mm
   
    % Previous Depths and Soil Moisture
    d_p = d_t;
    I_p = I_t;

    % Check if Nan or Inf occured in d_t
    if max(max(isinf(d_t))) == 1
        unstable_dt = 1;
        warning('The model became unstable.')
    end
   
    % Runoff Coefficient Calculation
    outflow_volume = nansum(nansum(outlet_flow))/1000*cell_area/3600*time_step*60 + outflow_volume;
    if flag_spatial_rainfall == 1
        if flag_inflow == 1
            inflow_volume = sum(sum(delta_inflow_agg'/1000.*n_inlets*cell_area)) + nansum(nansum(delta_p_agg))/1000*cell_area + inflow_volume; % check future
        else
            inflow_volume =  nansum(nansum(delta_p_agg))/1000*cell_area + inflow_volume; % check future           
        end
    elseif flag_spatial_rainfall ~= 1 && flag_inflow == 1
        inflow_volume = sum(sum(delta_inflow_agg'/1000.*n_inlets*cell_area)) + delta_p_agg/1000*drainage_area + inflow_volume; % check future        
    else
        inflow_volume = delta_p_agg/1000*drainage_area + inflow_volume; % check future        
    end
    % Increase the counter
    t = time_calculation_routing(k,1)/60 + t;
    time_step_save(k,2) = time_calculation_routing(k,1);
    time_step_save(k,1) = t;
    k = k + 1;
end