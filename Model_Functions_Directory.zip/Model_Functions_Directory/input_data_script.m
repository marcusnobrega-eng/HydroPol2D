%%%%%%%%%%%%%% INPUT DATA %%%%%%%%%%%%%%%%%%%
input_table = readtable(model_folder);

% Running Control
input_table_running_control = table2array(input_table(:,2));
time_save_ETP = input_table_running_control(1); % min
time_step_model = input_table_running_control(2)/60; % Dividing to convert to min
running_control.min_time_step = input_table_running_control(3);
running_control.max_time_step = input_table_running_control(4);
running_control.time_step_increments = input_table_running_control(5);
running_control.time_step_change = input_table_running_control(6);
Courant_Parameters.alfa_max = input_table_running_control(7);
Courant_Parameters.alfa_min = input_table_running_control(8);
Courant_Parameters.v_threshold = input_table_running_control(9);
Courant_Parameters.slope_alfa = input_table_running_control(10);
date_begin = input_table_running_control(11);
date_end = input_table_running_control(12);
% --- Routing Time --- %
running_control.routing_time = round((date_end - date_begin)*1440,4); % Minutes
date_begin = datetime(datestr(date_begin+datenum('30-Dec-1899')));
date_end = datetime(datestr(date_end+datenum('30-Dec-1899')));
if running_control.routing_time < 0
    error('Please make sure Date End is later than Date Begin.')
end

% Flags
input_table_flags = table2array(input_table(:,5));
flags.flag_rainfall = input_table_flags(1);
flags.flag_abstraction = input_table_flags(2);
flags.flag_inflow = input_table_flags(3);
flags.flag_waterbalance = input_table_flags(4);
flags.flag_waterquality = input_table_flags(5);
flags.flag_timestep = input_table_flags(6);
flags.flag_warmup = input_table_flags(7);
flags.flag_initial_buildup = input_table_flags(8);
flags.flag_wq_model = input_table_flags(9);
flags.flag_infiltration = input_table_flags(10);
flags.flag_critical = input_table_flags(11);
flags.flag_spatial_rainfall	 = input_table_flags(12);
flags.flag_D8	= input_table_flags(13);
flags.flag_diffusive = input_table_flags(14);
flags.flag_resample = input_table_flags(15);
flags.flag_smoothening = input_table_flags(16);
flags.flag_trunk = input_table_flags(17);
flags.flag_export_maps = input_table_flags(18);
flags.flag_fill_DEM = input_table_flags(19);
flags.flag_smooth_cells = input_table_flags(20);
flags.flag_reduce_DEM = input_table_flags(21);
flags.flag_ETP = input_table_flags(22);
flags.flag_obs_gauges = input_table_flags(23);
flags.flag_GPU = input_table_flags(24);
flags.flag_single = input_table_flags(25);
flags.flag_reservoir = input_table_flags(26);
flags.flag_human_instability = input_table_flags(27);
flags.flag_input_rainfall_map = input_table_flags(28);

% Matricial Variables
% input_table_matricial = table2array(input_table(:,9));
% running_control.time_step_matrices = input_table_matricial(1);
% factor_cells = input_table_matricial(2);

% Watershed Inputs and Cuts
input_table_watershed_inputs = table2array(input_table(:,12));
outlet_type = input_table_watershed_inputs(1);
slope_outlet = input_table_watershed_inputs(2);
x_outlet_begin = input_table_watershed_inputs(3);
x_outlet_end = input_table_watershed_inputs(4);
y_outlet_begin = input_table_watershed_inputs(5);
y_outlet_end = input_table_watershed_inputs(6);
n_outlets_data = input_table_watershed_inputs(7);

% Maps and Plots Control
input_table_map_plots = table2array(input_table(:,15));
running_control.record_time_maps = input_table_map_plots(1);
running_control.record_time_hydrographs = input_table_map_plots(2);
Pol_min = input_table_map_plots(3);
depth_wse = input_table_map_plots(4);
flags.flag_wse = input_table_map_plots(5);
flags.flag_elapsed_time = input_table_map_plots(6);
running_control.record_time_spatial_rainfall = input_table_map_plots(7);

% CA Parameters
input_table_CA_parameter = table2array(input_table(:,18));
CA_States.slope_min = input_table_CA_parameter(1);
CA_States.flow_tolerance = input_table_CA_parameter(2);
CA_States.depth_tolerance = input_table_CA_parameter(3);


% Abstraction
input_table_abstraction = table2array(input_table(:,21));
xmin = input_table_abstraction(1);
ymin = input_table_abstraction(2);
xmax = input_table_abstraction(3);
ymax = input_table_abstraction(4);
% GIS_data.xulcorner = input_table_abstraction(5);
% GIS_data.yulcorner = input_table_abstraction(6);

% Water Quality Inputs
input_table_WQ_parameter = table2array(input_table(:,24));
ADD = input_table_WQ_parameter(1);
min_Bt = input_table_WQ_parameter(2);
Bmin = input_table_WQ_parameter(3);
Bmax = input_table_WQ_parameter(4);


% DEM Smoothing, Imposemin & Resample
input_table_DEM = table2array(input_table(:,28));
GIS_data.min_area = input_table_DEM(1);
GIS_data.tau = input_table_DEM(2);
GIS_data.K_value = input_table_DEM(3);
GIS_data.sl = input_table_DEM(4);
GIS_data.resolution_resample = input_table_DEM(5);
GIS_data.alfa_1 = input_table_DEM(6);
GIS_data.alfa_2 = input_table_DEM(7);
GIS_data.beta_1 = input_table_DEM(8);
GIS_data.beta_2 = input_table_DEM(9);

% TopoToolbox Folder
topo_path = table2cell(input_table(1,31));

% Human Instability
if flags.flag_human_instability == 1
    Human_Instability.mu = table2array(input_table(1,34)); % friction coefficient
    Human_Instability.Cd = table2array(input_table(2,34));
    Human_Instability.ro_person = table2array(input_table(3,34)); % kg/m3
    Human_Instability.weight_person = table2array(input_table(4,34)); % kg
    Human_Instability.height_person = table2array(input_table(5,34)); % meters
    Human_Instability.width1_person = table2array(input_table(6,34)); % meters
    Human_Instability.width2_person = table2array(input_table(7,34)); % meters
    Human_Instability.ro_water = table2array(input_table(8,34)); % kg/m3
    Human_Instability.gravity = table2array(input_table(9,34)); % m/s2
else
    Human_Instability = [];
end

% Observed Gauges
input_table_observed = (input_table(2:end,37:39));
obs_gauges = table2array(input_table_observed(:,1)); % Indexes
gauges.num_obs_gauges = sum(~isnan(obs_gauges));
gauges.easting_obs_gauges_absolute = table2array(input_table_observed(1:gauges.num_obs_gauges,2)); % Easting Coordinates
gauges.northing_obs_gauges_absolute = table2array(input_table_observed(1:gauges.num_obs_gauges,3)); % Northing Coordinates
% --- Converting coordinates to local coordinates in pixels
gauges.easting_obs_gauges = round((-GIS_data.xulcorner + gauges.easting_obs_gauges_absolute)/Wshed_Properties.Resolution);
gauges.northing_obs_gauges = round((GIS_data.yulcorner - gauges.northing_obs_gauges_absolute)/Wshed_Properties.Resolution);

% Getting the labels
labels_observed = (input_table(2:(2+gauges.num_obs_gauges-1),40));
if flags.flag_obs_gauges == 1
    for i = 1:gauges.num_obs_gauges
        gauges.labels_observed_string{i,:} = string(labels_observed{i,:});
    end
end

% Design Storms
input_table_design = table2array((input_table(1:9,43)));
flags.flag_alternated_blocks = input_table_design(1);
flags.flag_huff = input_table_design(2);
Design_Storm_Parameters.RP = input_table_design(3); % year
Design_Storm_Parameters.Rainfall_Duration = input_table_design(4); % min
Design_Storm_Parameters.K = input_table_design(5); % K
Design_Storm_Parameters.a = input_table_design(6); % a
Design_Storm_Parameters.b = input_table_design(7); % b
Design_Storm_Parameters.c = input_table_design(8); % c
Design_Storm_Parameters.time_step = input_table_design(9); % min

if flags.flag_huff == 1 && flags.flag_alternated_blocks == 1
    error('Please, enter either Alternated Blocks or Huff hyetograph.')
end

% Input Rainfall Maps
if flags.flag_input_rainfall_map == 1
    input_table_rainfall = ((input_table(2:end,45:46)));
    Input_Rainfall.time = table2array(input_table_rainfall(:,1)); % % min
    Input_Rainfall.num_obs_maps = sum(~isnan(Input_Rainfall.time));
    Input_Rainfall.time = Input_Rainfall.time(1:Input_Rainfall.num_obs_maps);
    input_table_dir = input_table_rainfall(:,2);

    for i = 1:Input_Rainfall.num_obs_maps
        Input_Rainfall.labels_Directory{i,:} = string(input_table_dir{i,:});
    end
    flags.flag_spatial_rainfall = 1;
    flags.flag_rainfall = 1;
end

%%%%%%%%%%%%%% LULC DATA %%%%%%%%%%%%%%%%%%%
input_table = readtable('LULC_parameters.xlsx');
input_data = table2array(input_table(:,2:end)); % numbers
lulc_parameters = input_data(:,2:end);
n_lulc = sum(lulc_parameters(:,1)>=0); % Number of LULC
lulc_parameters = lulc_parameters(1:n_lulc,:);
imp_index = lulc_parameters(1,end);
% LULC Index
LULC_index = input_data(:,1);

%%%%%%%%%%%%%% SOIL DATA %%%%%%%%%%%%%%%%%%%
input_table = readtable('SOIL_parameters.xlsx');
input_data = table2array(input_table(:,2:end)); % numbers
soil_parameters = input_data(:,2:end); % Number of Soil Types
n_soil = sum(soil_parameters(:,1)>=0);
soil_parameters = soil_parameters(1:n_soil,:);
% SOIL Index
SOIL_index = input_data(:,1);
SOIL_name = input_table(:,1);

% Rainfall
if flags.flag_alternated_blocks ~= 1 && flags.flag_huff ~= 1
    input_table = readtable('Rainfall_Intensity_Data.xlsx');
    input_data = table2array(input_table);
    Rainfall_Parameters.intensity_rainfall = input_data(:,2); % mm/h
    Rainfall_Parameters.n_obs_rainfall = sum(Rainfall_Parameters.intensity_rainfall >= 0);
    Rainfall_Parameters.intensity_rainfall = Rainfall_Parameters.intensity_rainfall(1:Rainfall_Parameters.n_obs_rainfall);
    Rainfall_Parameters.time_rainfall = input_data(:,1); % min
    Rainfall_Parameters.time_step_rainfall = input_data(2,1) - input_data(1,1); % min
    Rainfall_Parameters.rainfall_duration = input_data(2,1) - input_data(1,1); % min
elseif flags.flag_alternated_blocks == 1 && flags.flag_input_rainfall_map ~= 1
    % Run Alternated Blocks Model
    [Rainfall_Parameters.time_rainfall,Rainfall_Parameters.intensity_rainfall,~,idf] = alternated_blocks(Design_Storm_Parameters.Rainfall_Duration(end),Design_Storm_Parameters.time_step,Design_Storm_Parameters.K,Design_Storm_Parameters.a,Design_Storm_Parameters.b,Design_Storm_Parameters.c,Design_Storm_Parameters.RP,1);
    Rainfall_Parameters.n_obs_rainfall = sum(Rainfall_Parameters.intensity_rainfall >= 0);
    Rainfall_Parameters.intensity_rainfall = Rainfall_Parameters.intensity_rainfall(1:Rainfall_Parameters.n_obs_rainfall);
    Rainfall_Parameters.time_step_rainfall = Design_Storm_Parameters.time_step; % min
    Rainfall_Parameters.rainfall_duration = Rainfall_Parameters.time_rainfall(end); % min
    % Routing Time >= Rainfall Duration
    running_control.routing_time = max(running_control.routing_time,Rainfall_Parameters.rainfall_duration);    
elseif flags.flag_huff == 1 && flags.flag_input_rainfall_map ~= 1
    % Run Huff Model
    [Rainfall_Parameters.time_rainfall,Rainfall_Parameters.intensity_rainfall,~] = Huff_Curves(Design_Storm_Parameters.Rainfall_Duration(end), Design_Storm_Parameters.time_step, Design_Storm_Parameters.K,Design_Storm_Parameters.a,Design_Storm_Parameters.b,Design_Storm_Parameters.c,Design_Storm_Parameters.RP,1);
    Rainfall_Parameters.n_obs_rainfall = sum(Rainfall_Parameters.intensity_rainfall >= 0);
    Rainfall_Parameters.intensity_rainfall = Rainfall_Parameters.intensity_rainfall(1:Rainfall_Parameters.n_obs_rainfall);
    Rainfall_Parameters.time_step_rainfall = Design_Storm_Parameters.time_step; % min
    Rainfall_Parameters.rainfall_duration = Rainfall_Parameters.time_rainfall(end); % min
    % Routing Time >= Rainfall Duration
    running_control.routing_time = max(running_control.routing_time,Rainfall_Parameters.rainfall_duration);    
end



% Load TopoToolBox Tools
addpath(genpath(char(topo_path)));

% Inflow
input_table = readtable('Inflow_Hydrograph.xlsx');
input_table_labels = input_table(1:2,:);
input_table_values = (input_table(3:end,:));
% --- Convert Everything to String
input_table_values = convertvars(input_table_values,[1:1:size(input_table_values,2)],'string');
% --- Converting Everything to Double
input_table_values = convertvars(input_table_values,[1:1:size(input_table_values,2)],'double');

n_inflows_max = 50;
for i = 1:n_inflows_max
    Inflow_Parameters.inflow_discharge(:,i) = table2array(input_table(3:end,(i-1)*5 + 2));
end
Inflow_Parameters.n_stream_gauges = sum(sum(Inflow_Parameters.inflow_discharge(1,:)>=0)); % Number of stream gauges
for i = 1:Inflow_Parameters.n_stream_gauges
    % Do we have to include Resolution/2 in the calculations?
    easting_inlet_cells(:,i) = round((-GIS_data.xulcorner + table2array(input_table_values(1,(i-1)*5 + 3)))/Wshed_Properties.Resolution);
    northing_inlet_cells(:,i) = round((GIS_data.yulcorner - table2array(input_table_values(1,(i-1)*5 + 4)))/Wshed_Properties.Resolution);
    Wshed_Properties.n_inlets(:,i) = sum(sum(easting_inlet_cells(:,i)>=0));
end
Inflow_Parameters.n_stream_obs = sum(sum(Inflow_Parameters.inflow_discharge(:,1)>=0)); % Number of stream data per gauge
Inflow_Parameters.time_inflow = table2array(input_table(3:Inflow_Parameters.n_stream_obs,1)); % min
Inflow_Parameters.time_step_inflow = (table2array(input_table(4,1)) - table2array(input_table(3,1))); % min

if flags.flag_inflow == 1
    if Wshed_Properties.n_inlets == 0
        error('Please, insert the inlet coordinate(s) in the Inflow_Hydrograph.xlsx file')
    end
end

% Entering a boundary condition for rainfall if design storms are used
if flags.flag_huff == 1 || flags.flag_alternated_blocks == 1 && flags.flag_input_rainfall_map ~= 1
    flags.flag_rainfall = 1;
    flags.flag_spatial_rainfall = 0;
end

Area = Wshed_Properties.Resolution^2*Wshed_Properties.n_inlets; % m2
Inflow_Parameters.inflow_discharge = Inflow_Parameters.inflow_discharge(:,1:Inflow_Parameters.n_stream_gauges);
Inflow_Parameters.inflow_hydrograph_rate = Inflow_Parameters.inflow_discharge./Area*1000*3600; % mm/h

clear input_data input_table

% Reservoir Data
if flags.flag_reservoir == 1
    input_table = readtable('Reservoir_Data.xlsx');
    Reservoir_Data.index = table2array(input_table(:,1));
    Reservoir_Data.x = table2array(input_table(:,2));
    Reservoir_Data.y = table2array(input_table(:,3));
    Reservoir_Data.Lef = table2array(input_table(:,4));
    Reservoir_Data.Dir = table2array(input_table(:,5));
    Reservoir_Data_Hv = table2array(input_table(:,6));
    Reservoir_Data.Cd = table2array(input_table(:,7));
    Reservoir_Data.Qreg = table2array(input_table(:,8));
    % Calculating Kv = Cd * Lef
    Reservoir_Data.Kv = Reservoir_Data.Cd.*Reservoir_Data.Lef;
end

clear input_table