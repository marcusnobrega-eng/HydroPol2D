%% 2-D Overland Flow Model
% % % % % % % % % % % % % Model Status % % % % % % % % % % % % % 
% ---------- Version 1.0 -------------
% Last Update - 9/15/2021

% ----------------- Infiltration model -------------- 
% It is used the Green-Ampt infiltration model to
% estimate infiltration losses. It is necessary to know soil properties
% such as: Hydraulic saturated condutivity (Ksat - mm/h), Initial soil moisture
% (teta_i), Saturated soil moisture (teta_sat), suction head (psi - mm) and
% Initial water content (I_0 - mm). These variables can be assigned
% according to the land use.
%
% ----------------- Non-linear reservoir model -----------------
% This model assumes the initial abstraction of each particular cell equal the value of h_0.
% This parameter is an input
% and should be given for pervious and impervious areas in mm
%
% ----------------- Build-up and Wash-off model -----------------
% For this model, it is necessary to know linear and exponential
% coefficients for build-up and wash-off for each particular cell,
% discretized in the grid. For that, it is assumed that the cells with the
% maximum value of roughness has the B_i_ha (kg/ha of initial accumulation), C_1_i
% and C_2_i (1/h) of wash-off values. These values should be filled in the
% script
% ----------------- Initial Data - General -----------------
clc
clear all
tic
%[dem,imp,inflow_cells,Resolution,LA,LB] = Initial_Data(); % Load Imp areas and DEM calling this function
load Elevation_Data.txt
load Land_Cover_Data.txt
input_data_script; % Load csv input data
dem = Elevation_Data;
imp = Land_Cover_Data;
% [dem,imp] = v_tilted(); % V-tilted
dem = gpuArray(dem); imp = gpuArray(imp);
cell_area = Resolution^2; % cell area in square meters
zzz = size(dem);
factor_cells = gpuArray(factor_cells);
% ----------------- Flow tolerance -----------------
% flow_tolerance = 1e-10; % mm/h
flow_tolerance = gpuArray(flow_tolerance);
% ----------------- Depth tolerance -----------------
depth_tolerance = gpuArray(depth_tolerance); % mm
[ny_max,nx_max] = size(dem);
% ------------ Inflow Cells  ------------
inflow_cells = zeros(ny_max,nx_max);
for i = 1:n_inlets
    x = inlet_cells(i,1);
    y = inlet_cells(i,2);
    inflow_cells(y,x) = 1;
end
% Rectangle At the Beginning of the Catchment]
% ------------ Rainfall Matrix ------------
% flag_rainfall = 0; % if 1, all watershed receive rainfall, else 0
flag_rainfall = gpuArray(flag_rainfall);
if flag_rainfall == 0
    rainfall_matrix = flag_rainfall*zeros(size(dem));
else
    rainfall_matrix = flag_rainfall*ones(size(dem));
end
rainfall_matrix = gpuArray(rainfall_matrix);
% ------------ Outlet ------------
outlet_index_fulldomain = gpuArray(zeros(zzz));
for i = x_outlet_begin:x_outlet_end
    for j = y_outlet_begin:y_outlet_end
        outlet_index_fulldomain(j,i) = 1;
    end
end
outlet_index = outlet_index_fulldomain;
%% ------------ Recording time of outputs (i.e., flows, concentrations ...) ------------
% Calculations
steps = routing_time/time_step_model; % number of calculation steps
number_of_records = floor(steps*time_step_model/record_time_maps); % number of stored data (size of the vector)
% Checking if the recording time is working
if number_of_records == 0
    error('The recording time is larger than the routing time, please change it')
end
time_records = gpuArray((0:record_time_maps:routing_time)); % time in minutes
time_record_hydrograph = gpuArray((0:record_time_hydrographs:routing_time)); % time in minutes
time_change_records = gpuArray((0:time_step_change/60:routing_time)); % time in minutes
time_change_matrices = gpuArray((0:time_step_matrices/60:routing_time)); % time in minutes
% vector to store data
time_store = time_records./time_step_model; % number of steps necessary to reach the record vector
time_store(1) = 1; % the zero is the firt time step
%% Inflow and Precipitation data
inflow_hydrograph_rate = gpuArray(inflow_hydrograph_rate*flag_inflow);
intensity_rainfall = gpuArray(intensity_rainfall*flag_rainfall); % If flag_rainfall is zero, no rainfall is considered
%% Grid Domain
%%%%%% ORIGINAL GRID %%%%%%
% flag_abstraction = 1;
if flag_abstraction == 0
    xmin = 1; %initial position x in the grid (collums)
    ymin = 1; % lines (up to down)
    xmax = zzz(2);
    ymax = zzz(1);
else
% Use Input Data
end
inflow_cells = gpuArray(inflow_cells(ymin:ymax,xmin:xmax));
outlet_index = outlet_index(ymin:ymax,xmin:xmax);
spatial_domain = gpuArray(zeros(size(inflow_cells)));
%% Determining soil properties for each cell, according to the imperviousness and Cutting all full-domain matrices
elevation = dem(ymin:ymax,xmin:xmax); % using only specified grid
rainfall_matrix = gpuArray(rainfall_matrix(ymin:ymax,xmin:xmax));
elevation = gpuArray(elevation);
dem = dem(ymin:ymax,xmin:xmax); %% ATENTION HERE
dem = gpuArray(dem);
lulc_matrix = imp(ymin:ymax,xmin:xmax); % using only specified grid
idx = elevation < 0; %find where elevation is -9999 or negative
elevation(idx) = inf; % change thoese values for inf
idx = lulc_matrix < 0; % same thing with impervious map
lulc_matrix(idx) = inf;
%%%%%%%%%%%%%%% Preallocating arrays to avoid big computational efforts
y_1 = length(ymin:ymax);
x_1 = length(xmin:xmax);
roughness = spatial_domain;
d_0 = spatial_domain; h_0 = spatial_domain ;psi = spatial_domain;
ksat = spatial_domain; teta_i = spatial_domain;
teta_sat = spatial_domain; I_0 = spatial_domain;
if flag_waterquality == 1 % Build-up and Wash-off matrices
    C_1 = spatial_domain;
    C_2  = spatial_domain;
    C_3 = spatial_domain;
    C_4 = spatial_domain;
    B_0 = spatial_domain;
end
%% ----------------- Fill the variables -----------------
idx_1 = lulc_matrix == LULC_index(1,1); % find imp1 surfaces
idx_2 = lulc_matrix == LULC_index(2,1); % find per2 surfaces
idx_3 = lulc_matrix == LULC_index(3,1); % find per3 surfaces
idx_4 = lulc_matrix == LULC_index(4,1); % find per4 surfaces
idx_5 = lulc_matrix == LULC_index(5,1); % find per5 surfaces
idx_6 = lulc_matrix == LULC_index(6,1); % find per6 surfaces

idx = cat(3,idx_1,idx_2,idx_3,idx_4,idx_5,idx_6);
impervious_cells = sum(idx_1);
pervious_cells = sum(idx(:,:,2:6),3);
for i = 1:6 % 6 types of land use and land cover
    roughness(idx(:,:,i)) = lulc_parameters(i,1); % assigning values for roughness at impervious areas
    ksat(idx(:,:,i)) = lulc_parameters(i,2); % similar things happening below
    d_0(idx(:,:,i)) = lulc_parameters(i,3);
    h_0(idx(:,:,i)) = lulc_parameters(i,4);
    psi(idx(:,:,i)) = lulc_parameters(i,5);
    I_0(idx(:,:,i)) = lulc_parameters(i,6);
    teta_sat(idx(:,:,i)) = lulc_parameters(i,7);
    teta_i(idx(:,:,i)) = lulc_parameters(i,8);
    if flag_waterquality == 1 % Only if water quality is being modeled
       C_1(idx(:,:,i)) =  lulc_parameters(i,9);
       C_2(idx(:,:,i)) =  lulc_parameters(i,10);
       C_3(idx(:,:,i)) =  lulc_parameters(i,11);
       C_4(idx(:,:,i)) =  lulc_parameters(i,12);
       if i == 6
           % Initial Build-up Calculation
            B_0 = C_1.*(1 - exp(1).^(C_2*ADD)); % kg/ha
            B_t = B_0*cell_area/10^4; % kg
       end
    end
end
% warm-up data
load depths_warmup_RAS.txt
d_0 = gpuArray(depths_warmup_RAS*0.3024*1000);
idx = d_0 == -9999;
d_0(idx) = 0;
clear idx % clear this matrices to avoid huge storage data
% ----------------- Full Domain Cells -----------------
rainfall_matrix_full_domain = rainfall_matrix;
teta_sat_fulldomain = teta_sat;
teta_i_fulldomain = teta_i;
psi_fulldomain = psi;
roughness_fulldomain = roughness;
ksat_fulldomain = ksat;
h_0_fulldomain = h_0;
I_p_fulldomain = I_0;
I_t_fulldomain = I_0;
outlet_index_fulldomain = outlet_index_fulldomain(ymin:ymax,xmin:xmax);
%%%% New xmax and ymax
xmin = 1; %initial position x in the grid (collums)
ymin = 1; % lines (up to down)
zzz = size(elevation);
xmax = zzz(2);
ymax = zzz(1);
%% Conversion of inflow into the time-step of calculations
inflow_length = length(inflow_hydrograph_rate);
inflow_discretized = zeros(1,ceil(inflow_length*time_step_inflow/time_step_model)); % Preallocating
for i =1:((inflow_length-1)*time_step_inflow/time_step_model)
    inflow_discretized(i) = inflow_hydrograph_rate(ceil((round(i*time_step_model/time_step_inflow,12)))); % Discretized into moldel's time-step
end
%% Conversion of rainfall into the time-step of calculations
intensity_rainfall_length = length(intensity_rainfall);
intensity_discretized = zeros(1,ceil(intensity_rainfall_length*time_step_rainfall/time_step_model)); % Preallocating
for i =1:(intensity_rainfall_length*time_step_rainfall/time_step_model)
    intensity_discretized(i) = intensity_rainfall(ceil((round(i*time_step_model/time_step_rainfall,12))));  % Discretized into moldel's time-step
end
%% Determination of grid parameters and outlet coordinates (Whole Domain)
nx_max = length(elevation(1,:)); % number of x cells
ny_max = length(elevation(:,1)); % number of y cells
% calculates the number of non-inf cells to determine the watershed area
matrix_inf = isinf(elevation);
number_inf = sum(sum(matrix_inf));
drainage_area = (nx_max*ny_max - number_inf)*Resolution^2;
impervious_area = sum(sum(impervious_cells))*cell_area;
pervious_area = sum(sum(pervious_cells))*cell_area;
impervious_rate = impervious_area/drainage_area;
pervious_rate = pervious_area/drainage_area;
%% Calculation of accumulated and incremental inflow on the inflow cells
[~,delta_inflow,inflow_intensity] = accumulated_incremental(steps,inflow_discretized,time_step_model);
time_deltainflow = gpuArray(cumsum(ones(1,length(delta_inflow))*time_step_model)); % Vector with indices 
delta_inflow = gpuArray(delta_inflow);
%% Calculation of accumulated and incremental precipitation in each cell
[~,delta_p,rainfall_intensity] = accumulated_incremental(steps,intensity_discretized,time_step_model);
delta_p = gpuArray(delta_p);
rainfall_intensity = gpuArray(rainfall_intensity);
time_deltap = gpuArray(cumsum(ones(1,length(delta_p))*time_step_model));
%% Pre allocating arrays
Total_Inflow = 0;
d_t = spatial_domain;
outflow_cms_t = spatial_domain;
inf_m3s_t = spatial_domain;
q_exut_t = spatial_domain;
% ----------------- Space dependent arrays -----------------
qout_left_t = spatial_domain;
qout_right_t = spatial_domain;
qout_up_t = spatial_domain;
qout_down_t = spatial_domain;
d_p = spatial_domain;
hydraulic_radius_t = spatial_domain;
d_avg = spatial_domain;
qin_t = spatial_domain;
vel_left = spatial_domain;
vel_right = spatial_domain;
vel_up = spatial_domain;
vel_down = spatial_domain;
I_tot_end = gpuArray(ones(size(spatial_domain))); %%% ATTENTION HERE
I_tot_end_cell_fulldomain = spatial_domain;
% ----------------- Time dependent arrays -----------------
time_size = length(time_store);
d = gpuArray(zeros(ny_max,nx_max,time_size));
outet_hydrograph = gpuArray(zeros(time_size,1));
time_hydrograph = gpuArray(zeros(time_size,1));
if flag_waterquality == 1
    Pol_Conc_Map = gpuArray(zeros(ny_max,nx_max,time_size));
    outet_pollutograph = gpuArray(zeros(time_size,1));
end
%% Clearing a few variables
clear accum_precipitation precipitation imp Land_Cover_Data Elevation_DATA intensity_discretized idx_ idx_1 matrix_inf idx accum_inflow col col_check d_0_imp d_0_per h_0_imp h_0_per I_0_per I_0_imp inflow_discretized
%% Main Routing
tic
% ----------------- Find Initial Domain ----------------- 
[y_depth_stored, x_depth_stored] = find(d_0 > 0);
[row_check, col_check] = find(inflow_cells > 0);
[row_check_rainfall, col_check_rainfall] = find(rainfall_matrix > 0);
cells_check = [y_depth_stored x_depth_stored; row_check col_check; row_check_rainfall, col_check_rainfall];
cells_check = unique(cells_check,'rows');
% flows_cells = gpuArray(zeros(ny_max + 2,nx_max + 2));
flows_cells = gpuArray(zeros(ny_max,nx_max)); %%% ATTENTION HERE
% ----------------- Initialize Variables -----------------
I_t = I_0;
I_p = I_0;
time_calculation_routing = gpuArray(zeros(steps,1));
k = 1; % Start Counter
actual_record_state = 1;
last_record_maps = 1;
last_record_hydrograph = 1;
delta_inflow_agg = delta_inflow(1,1);
delta_p_agg = gpuArray(delta_p(1,1)*flag_rainfall);
time_step = time_step_model;
I = zeros(4,1); % Volumes in each direction
t = time_step_model; % minutes
time_save_previous = 0; % minutes
% delta_h_matrix = zeros(1,5);
Previous_Volume = 0;
t_previous = 0;
coordinate_x = 1;
coordinate_y = 1;
time_matrices_previous = 0;
% handle = waitbar(0, 'Percentage Complete');  
step_error = gpuArray(zeros(1,steps));
time_step_cell = gpuArray(max_time_step*ones(1,steps));
relative_vol_error = gpuArray(zeros(1,steps));
I_cell = gpuArray(zeros(ny_max,nx_max,5));
while t <= routing_time
    flows_cells = zeros(ny_max,nx_max);
    %% Infiltration and Available Depth
    if k == 1
        C = ksat.*(1 + ((d_0 + psi).*(teta_sat - teta_i))./I_0); % matrix form
        Inflow_Rate = (delta_p_agg*rainfall_matrix + delta_inflow_agg*inflow_cells + d_0)./(time_step/60);
        tx = min(C,Inflow_Rate);
        I_t = I_0 + tx*time_step/60;
        pef = delta_p_agg*rainfall_matrix + delta_inflow_agg*inflow_cells - tx*time_step/60;
        d_t = d_0 + pef;
        inf_m3s_t = tx/1000.*cell_area/3600;
    else
        %Effective precipitation - Green-Ampt(1911)
        C = ksat.*(1 + ((d_p + psi).*(teta_sat - teta_i))./I_p); % matrix form
        Inflow_Rate = (delta_p_agg*rainfall_matrix + delta_inflow_agg*inflow_cells + d_p)./(time_step/60);
        tx = min(C,Inflow_Rate);
        I_t = I_p + tx*time_step/60;
        %                 pef = delta_p_agg + delta_inflow_agg*inflow_cells(y,x) - tx*time_step/60; %effective precipitation in mm
        pef = delta_p_agg*rainfall_matrix + delta_inflow_agg*inflow_cells - tx*time_step/60;
        d_t = d_p + pef; %% ATTENTION HERE
        inf_m3s_t = tx/1000.*cell_area/3600;
    end
    total_available_depth = d_t;
    
    %%%% ELEVATIONS %%%
                elevation_left_t = [zeros(ny_max,1),elevation(:,1:(nx_max-1))];
                elevation_right_t = [elevation(:,(2:(nx_max))) zeros(ny_max,1)];
                elevation_up_t = [zeros(1,nx_max) ; elevation(1:(ny_max-1),:)];
                elevation_down_t = [elevation(2:(ny_max),:) ; zeros(1,nx_max)];        
                
    %%%% WATER DEPTHS %%%
                d_left_cell = [zeros(ny_max,1),total_available_depth(:,1:(nx_max-1))];
                d_right_cell = [total_available_depth(:,(2:(nx_max))) zeros(ny_max,1)];
                d_up_cell = [zeros(1,nx_max) ; total_available_depth(1:(ny_max-1),:)];
                d_down_cell = [total_available_depth(2:(ny_max),:) ; zeros(1,nx_max)];                               
     %%%% ASSIGNING VALUES %%%
                elevation_cell = elevation;
                d_t_cell = total_available_depth;
                hydraulic_radius_t_cell = hydraulic_radius_t;
                roughness_cell = roughness;
                h_0_cell = h_0;
                I_tot_end_cell = I_tot_end; % Attention here                     
    %%  Flood routing for each cell
            [qout_left_t,qout_right_t,qout_up_t,qout_down_t,outlet_flow,d_t,I_tot_end,I_cell] = CA_Routing(elevation_cell,elevation_left_t,elevation_right_t,elevation_up_t,elevation_down_t,d_t_cell,d_left_cell,d_right_cell,d_up_cell,d_down_cell,roughness_cell,cell_area,time_step,h_0_cell,Resolution,I_tot_end_cell,outlet_index,outlet_type,slope_outlet);                
            qin_left_t = [zeros(ny_max,1),qout_right_t(:,1:(nx_max-1))];
            qin_right_t = [qout_left_t(:,(2:(nx_max))) zeros(ny_max,1)];
            qin_up_t = [zeros(1,nx_max) ; qout_down_t(1:(ny_max-1),:)];
            qin_down_t = [qout_up_t(2:(ny_max),:) ; zeros(1,nx_max)];
            qin_t = qin_left_t + qin_right_t + qin_up_t + qin_down_t;            
                    
            idx = qin_t > flow_tolerance;
            idx2 = qin_t <= flow_tolerance;
            flows_cells(idx) = 1;
            flows_cells(idx2) = 0;  
            
            if flag_waterquality == 1
                [B_t,P_conc,Out_Conc] = build_up_wash_off(C_3,C_4,qout_left_t,qout_right_t,qout_up_t,qout_down_t,outlet_flow,B_t,time_step,nx_max,ny_max,cell_area,outlet_index);
            end
        %% New Time-step Calculation
        pos_save = find(time_change_records < t,1,'last');
        time_save = time_change_records(pos_save); % min
        delta_time_save = time_save - time_save_previous;
        time_save_previous = time_save;
        actual_record_timestep = find(time_change_records < t,1,'last');
        if delta_time_save > 0
            if flag_timestep == 0
                %%% SOLUTION FOR COURANT METHOD %%%
                d_left_cell = [zeros(ny_max,1),d_t(:,1:(nx_max-1))];
                d_right_cell = [d_t(:,(2:(nx_max))) zeros(ny_max,1)];
                d_up_cell = [zeros(1,nx_max) ; d_t(1:(ny_max-1),:)];%
                d_down_cell = [d_t(2:(ny_max),:) ; zeros(1,nx_max)];

                vel_left = (I_cell(:,:,1)./(0.5/1000.*(d_t + d_left_cell).*Resolution))/(time_step*60); % m/s
                vel_right = (I_cell(:,:,2)./(0.5/1000.*(d_t + d_right_cell).*Resolution))/(time_step*60);
                vel_up = (I_cell(:,:,3)./(0.5/1000.*(d_t + d_up_cell).*Resolution))/(time_step*60); % m/s;;
                vel_down = (I_cell(:,:,4)./(0.5/1000.*(d_t + d_down_cell).*Resolution))/(time_step*60); % m/s;

                %%%%%%%%%%%%%% Find the Maximum Velocity
                max_velocity_left = max(max(vel_left));
                max_velocity_right = max(max(vel_right));
                max_velocity_up = max(max(vel_up));
                max_velocity_down = max(max(vel_down));
                velocity_vector = [max_velocity_left, max_velocity_right, max_velocity_up, max_velocity_down];
                max_velocity = max(velocity_vector);
                time_step_factor = alfa;
                new_timestep = time_step_factor*(Resolution/max_velocity); % seconds
                t_previous = t;
                previous_time_step = time_step;
            else             % % % % % % % %  Solution for the Stable Method - Time-step refreshment
                % Water Slopes Calculation
                wse_cell = elevation_cell + d_t_cell/1000;
                slope(:,:,1) = 1/Resolution*(wse_cell - elevation_left_t - d_left_cell/1000);
                slope(:,:,2) = 1/Resolution*(wse_cell - elevation_right_t - d_right_cell/1000);
                slope(:,:,3) = 1/Resolution*(wse_cell - elevation_up_t - d_up_cell/1000);
                slope(:,:,4) = 1/Resolution*(wse_cell - elevation_down_t - d_down_cell/1000);
                slope_cell = max(min(slope,[],3),slope_min); % Minimum assumed slope
                time_step_cell = max((Resolution^2/4)*(2*roughness./((d_t_cell/1000).^(5/3)).*sqrt(slope_cell)),min_time_step);
                new_timestep = min(min((time_step_cell)));
                t_previous = t;
                previous_time_step = time_step;
            end
            % Rounding time-step to min_timestep or max_timestep with the required
            % precision
            time_calculation_routing(k,1) = new_timestep;
            time_calculation_routing(k,1) = max(time_step_increments*floor(time_calculation_routing(k,1)/time_step_increments),min_time_step);
            time_calculation_routing(k,1) = min(time_calculation_routing(k,1),max_time_step);
            time_step = time_calculation_routing(k,1)/60; % new time-step for the next run
        elseif  k == 1
            time_calculation_routing(k,1) = time_step*60; % sec
        else
            time_calculation_routing(k,1) = time_calculation_routing(k-1,1);
        end
            %% Agregating Inflows to the New Time-step    
        z1 = find(time_deltainflow > t_previous,1,'first'); % begin of the time-step
        z2 = find(time_deltainflow <= t,1,'last'); % end of the time-step
        if z2 < z1
            z2 = z1;
        end
        if time_step >= time_step_model
            delta_inflow_agg = mean(delta_inflow(1,z1:z2))/(time_step_model*60)*time_step*60;
        else
            delta_inflow_agg = delta_inflow(1,z1)/(time_step_model*60)*time_step*60;
        end
        if k == 1
            t_previous = time_calculation_routing(k,1)/60;
        else
            t_previous = t;
        end
    %% Agregating Precipitation to the New Time-step    
    if flag_rainfall > 0        
        z1 = find(time_deltap > t_previous,1,'first'); % begin of the time-step
        z2 = find(time_deltap <= t,1,'last'); % end of the time-step
        if z2 < z1
            z2 = z1;
        end
        if time_step >= time_step_model
            delta_p_agg = mean(delta_p(1,z1:z2))/(time_step_model*60)*time_step*60;
        else
            delta_p_agg = delta_p(1,z1)/(time_step_model*60)*time_step*60;
        end
        if k == 1
            t_previous = time_calculation_routing(k,1)/60;
        else
            t_previous = t;
        end
    else
    end       
    
%% New Domain - Matrices
    pos_matrices = find(time_change_matrices < t,1,'last');
    time_matrices = time_change_matrices(pos_matrices); % min
    if k == 1
        time_matrices = 1;
    end
    delta_time_matrices = time_matrices - time_matrices_previous;
    time_matrices_previous = time_matrices;
    
    if delta_time_matrices > 0    
% Finding cells receiving water %%
%%% Local Coordinate System from the begining of the Domain
    [y_receiving, x_receiving] = find(flows_cells>0);
    %%%% Finding cells with stored water %%%%
    [y_depth_stored, x_depth_stored] = find(d_t > depth_tolerance);
    [row_check, col_check] = find(inflow_cells > 0);
    cells_check = [y_receiving x_receiving ; y_depth_stored x_depth_stored; row_check col_check];
    cells_check = unique(cells_check,'rows');    % Domain Fronteirs - Global Coordinate System
        
    xmin_cells= (min(cells_check(:,2)) -1 ) + coordinate_x;
    xmin_cells_t = xmin_cells; % Refresh
    xmax_cells = (max(cells_check(:,2)) -1 ) + coordinate_x;
    
    ymin_cells = (min(cells_check(:,1)) - 1 ) + coordinate_y;
    ymin_cells_t = ymin_cells;
    ymax_cells = (max(cells_check(:,1)) - 1 ) + coordinate_y;        
        
    %%% Min Values (Only works in the absolute coordinate reference systen)
    xmin_domain_new = max(xmin_cells - factor_cells,1);
    ymin_domain_new = max(ymin_cells - factor_cells,1);    

    %%% Max Values
    xmax_domain_new = min(xmax_cells + factor_cells,xmax); %xmax is wrong here
    ymax_domain_new = min(ymax_cells + factor_cells,ymax);
    domain = gpuArray(zeros(ymax_domain_new - ymin_domain_new + 1,xmax_domain_new - xmin_domain_new  + 1));
    %%%%% Domain is in the local coordinate system 
    % New Coordinates - Local of the 1st cell in the Global Coordinate System
    coordinate_x_previous = coordinate_x;
    coordinate_y_previous = coordinate_y;
    if coordinate_x == 1 % First cut in the domain (outside border)
        coordinate_x = xmin_domain_new; % Using the outside reference (new reference)
        coordinate_y = ymin_domain_new;
        begin = 1; % Initial Abstraction of the Matrices
    else
        begin = 0;
        coordinate_x = xmin_domain_new;
        coordinate_y = ymin_domain_new;  
    end      
    
    % Matrices Sizes - Deslocation (Local Coordinate System)
    dymax_matrix = ymax_cells - coordinate_y + 1; % Top of the matrix
    dymin_matrix = ymin_cells - coordinate_y + 1; % Bottom
    dxmax_matrix = xmax_cells - coordinate_x + 1; % Right side   
    dxmin_matrix = xmin_cells - coordinate_x + 1; % Left side
    [ny_max,nx_max] = size(domain);
    
    %%%% Abstracted Matrices 
    if begin == 1        
        ymin_domain_abstracted = ymin_cells - 0; % Already in the right coordinate system
        ymax_domain_abstracted = ymax_cells - 0;
        xmin_domain_abstracted = xmin_cells - 0;
        xmax_domain_abstracted = xmax_cells - 0; 
    else
        ymin_domain_abstracted = ymin_cells - coordinate_y_previous + 1;
        ymax_domain_abstracted = ymax_cells - coordinate_y_previous + 1;
        xmin_domain_abstracted = xmin_cells - coordinate_x_previous + 1;
        xmax_domain_abstracted = xmax_cells - coordinate_x_previous + 1;        
    end
          
   
    % New Matrices
    %%% Depths
    d_t = resize_matrix(d_t,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
%     surf(d_t); view(0,90); xlabel('x'); ylabel('y')
    %%% Inflow Cells
    inflow_cells = resize_matrix(inflow_cells,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    %%% Rainfall Matrix
    rainfall_matrix = resize_matrix(rainfall_matrix,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    %%% Flows Cells
    flows_cells = resize_matrix(flows_cells,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    %%% Inundation Cells
%     inundated_cells = resize_matrix(inundated_cells,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    %%% Qins
    qin_t = resize_matrix(qin_t,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
%     qout_left_t = resize_matrix(qout_left_t,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
%     qout_right_t = resize_matrix(qout_right_t,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
%     qout_up_t = resize_matrix(qout_up_t,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
%     qout_down_t = resize_matrix(qout_down_t,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    % Velocities
    vel_down = resize_matrix(vel_down,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    vel_up = resize_matrix(vel_up,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    vel_left = resize_matrix(vel_left,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    vel_right = resize_matrix(vel_right,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);
    % I_tot_end_cell
    I_tot_end = resize_matrix(I_tot_end,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);    
    I_tot_end_cell = I_tot_end;
    % I_cell
    I_cell = resize_matrix(I_cell,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,5);    

    %%%% All Domain Cells %%%%
    %%% Elevation
    elevation = dem(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);
    % Infiltration Parameters
    teta_sat = teta_sat_fulldomain(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);
    teta_i = teta_i_fulldomain(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);
    psi = psi_fulldomain(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);
    ksat = ksat_fulldomain(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);
    %  Roughness
    roughness = roughness_fulldomain(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);
    % Initial Abstraction
    h_0 = h_0_fulldomain(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);
    % Accumulated Infiltration
    domain_infiltration = I_0(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);    
    I_t = resize_matrix(I_t,domain_infiltration,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix,1);    
    I_p = I_t;
    % Outlet Cells
    outlet_index = outlet_index_fulldomain(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);    
    % Rainfall Cells
    rainfall_matrix = rainfall_matrix_full_domain(ymin_domain_new:ymax_domain_new,xmin_domain_new:xmax_domain_new);    
    
    % Cells Check
    [y_receiving, x_receiving] = find(flows_cells>0);
    [y_depth_stored, x_depth_stored] = find(d_t > depth_tolerance);
    [row_check, col_check] = find(inflow_cells > 0);
    cells_check = [y_receiving x_receiving ; y_depth_stored x_depth_stored; row_check col_check];
    cells_check = unique(cells_check,'rows');    
    end          
    %% Inflows and Depth Refreshments 
    d_t = d_t + qin_t*time_step/60; 
    % Clearing stored values
%     qin_t = zeros(ny_max,nx_max);
    qout_left_t = zeros(ny_max,nx_max);
    qout_right_t = zeros(ny_max,nx_max);
    qout_up_t = zeros(ny_max,nx_max);
    qout_down_t = zeros(ny_max,nx_max);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    
    %% Checking Water Balance and Saving State Variables %%%%
    if flag_waterbalance == 1
    Delta_Total_Inflow = delta_inflow_agg/1000*n_inlets*cell_area + delta_p_agg/1000*(ny_max*nx_max)*cell_area - sum(sum(outlet_flow))/1000*cell_area*time_step/60; % m3
    if k == 1 % add initial depths
        Total_Inflow = Delta_Total_Inflow + sum(sum(d_0/1000*cell_area)); % Cumulative in m3
        Previous_Volume = sum(sum(d_0/1000*cell_area));
    else
        Total_Inflow = Total_Inflow + Delta_Total_Inflow; % Cumulative in m3
    end    
    % Stored Water 
    Stored_Volume = sum(sum(cell_area/1000.*d_t)) + sum(sum((I_t - I_p)/1000*cell_area)); % m3 of water depths + infiltration
    Delta_Stored = Stored_Volume - Previous_Volume; % m3
    % Jump the previous volume and calculate at the end
    step_error(k) = Delta_Stored/Delta_Total_Inflow;    
    % Water Balance Error
    relative_vol_error(k) = (Stored_Volume - Total_Inflow) / Total_Inflow*100;
    relative_vol_error(k);
%     [step_error(k) relative_vol_error(k) Total_Inflow Stored_Volume];
%     time_step*60;    
%     Extra depth to correct water balance - Alternative 1 (Inflow Cells)
    extra_depth = (Delta_Total_Inflow - Delta_Stored) /(n_inlets*cell_area)*1000;
%     zzz(k) = extra_depth;
%         extra_depth = 0;
    d_t  = d_t + inflow_cells*extra_depth;    
%     % Extra depth to correct water balance - Alternative 2 (Cells_check)
%     extra_depth = max((Delta_Total_Inflow - Delta_Stored)/(size(cells_check,1)*cell_area)*1000,-500); % ATTENTION HERE
%     % Depth Refreshment
%     idx_nundated = inundated_cells > 0;
%     d_t(idx_nundated) = d_t(idx_nundated) + extra_depth;     
%     % Recalculate Water Balance
        % Stored Water
    Stored_Volume = sum(sum(cell_area/1000*d_t)); % m3 (d_t already refreshed)
    Delta_Stored = Stored_Volume - Previous_Volume; % m3
    % Refresh Previous Volume
    Previous_Volume = Stored_Volume; % m3
    step_error(k) = Delta_Stored/Delta_Total_Inflow;  
    
    % Water Balance Error
    relative_vol_error(k) = (Stored_Volume - Total_Inflow) / Total_Inflow*100;
    relative_vol_error(k);
    end
    
    %% Saving Plotting Values - Recording Time
    % Maps
    actual_record_state = find(time_records < t,1,'last');
    delta_record = actual_record_state - last_record_maps;
    last_record_maps = actual_record_state;    
    
    if k == 1
        d((coordinate_y:coordinate_y + ny_max - 1),(coordinate_x:coordinate_x + nx_max - 1),1) = d_t;
    elseif delta_record > 0
        t_store = actual_record_state;
        d((coordinate_y:coordinate_y + ny_max - 1),(coordinate_x:coordinate_x + nx_max - 1),t_store) = d_t;
    end % Calls the sub
    % Hydrographs
    actual_record_hydrograph = find(time_record_hydrograph < t,1,'last');
    delta_record_hydrograph = actual_record_hydrograph - last_record_hydrograph;
    last_record_hydrograph = actual_record_hydrograph;        
    
    if k == 1
        outet_hydrograph(1,1) = sum(sum(outlet_flow))/1000*cell_area/3600; % m3/s
        time_hydrograph(1,1) = time_calculation_routing(k,1);
        if flag_waterquality == 1
            outet_pollutograph(1,1) = Out_Conc;
        end        
    elseif delta_record_hydrograph > 0
        t_store = actual_record_hydrograph;
        outet_hydrograph(t_store,1) = sum(sum(outlet_flow))/1000*cell_area/3600; % m3/s
        time_hydrograph(t_store,1) = t;
        if flag_waterquality == 1
            outet_pollutograph(t_store,1) = Out_Conc;
        end
        %         waitbar(t/routing_time);
        [t/routing_time*100 time_step*60] %tracking the percentage of the calculations
    end % Calls the sub    
    
    % Previous Depths
    d_p = d_t;    
    I_p = I_t;
    % Increase the counter
    t = time_calculation_routing(k,1)/60 + t;
    k = k + 1; 
end
toc
% Double-checking if everything were saved
d((coordinate_y:coordinate_y + ny_max - 1),(coordinate_x:coordinate_x + nx_max - 1),end) = d_t;
outet_hydrograph(t_store,end) = sum(sum(outlet_flow))/1000*cell_area/3600;
time_hydrograph(end,1) = t;
if flag_waterquality == 1
    outet_pollutograph(end,1) = Out_Conc;
end
%% Exporting Results
% Outlet Hydrograph
plot(gather(time_hydrograph),gather(outet_hydrograph),'LineWidth',1.5','color','black'); xlabel('Time (min)','interpreter','latex'); ylabel('Flow Dishcarge $(m^3/s)$','interpreter','latex'); set(gca,'FontSize',12); 
hold on 
yyaxis right; set(gca,'ydir','reverse','ycolor','black');
plot(gather(time_rainfall),gather(intensity_rainfall),'LineWidth',1.5,'color','blue') 
ylabel('Intensity (mm/h)','interpreter','latex'); ylim([0,max(gather(intensity_rainfall)) + 200]);
if flag_inflow == 1
    hold on
    yyaxis left; set(gca,'ydir','normal','ycolor','black');
    plot(gather(time_inflow),gather(inflow_discharge),'LineWidth',1.5','color','black','LineStyle','--'); xlabel('Time (min)','interpreter','latex');
    ylim([0 max(max(gather(outet_hydrograph))*1.2,max(gather(inflow_discharge)))]); 
    legend('Outflow','Rainfall','Inflow');
else
    legend('Outflow','Inflow');
end
exportgraphics(gcf,'Hydrograph.pdf','ContentType','vector')
Outlet_Hydrograph_Data = table(gather(time_hydrograph),gather(outet_hydrograph),'VariableNames',{'Time (min)','Flow (m3/s)'});
writetable(Outlet_Hydrograph_Data)
if flag_waterquality == 1
    plot(gather(time_rainfall),gather(outet_pollutograph),'LineWidth',1.5,'color','Red') ;
    xlabel('Time (min)','Interpreter','Latex');
    ylabel('Pol. Concentration (mg/L)','Interpreter','Latex')
    exportgraphics(gcf,'Pollutograph.pdf','ContentType','vector')
end

% Rasters
for i = 1:length(time_records)
    time_map = time_records(i);
    if flag_wse == 0        
        FileName = strcat('Flood_Depths_t_', num2str(time_map),'min');
        raster_exportion = d(:,:,i)/1000;
    else
        FileName = strcat('Water_Surface_Elevation_t_', num2str(time_map),'min');
        idx = d < depth_wse*1000;
        raster_exportion = d(:,:,i)/1000 + dem;
        raster_exportion(idx) = 0;
    end
    % Save Map
    SaveAsciiRaster(raster_exportion,Resolution,xllupcorner,yllupcorner,FileName)
    % Water Quality
    if flag_waterquality == 1
        FileName = strcat('Pollutant_Concentration', num2str(time_map),'min');
        raster_exportion = Pol_Conc_Map(:,:,i)/1000;
        SaveAsciiRaster(raster_exportion,Resolution,xllupcorner,yllupcorner,FileName)
    end        
end
% Maximum
if flag_wse == 0 
    raster_exportion = max(d,[],3)/1000;
    FileName = strcat('Max_Flood_Depths');
    SaveAsciiRaster(raster_exportion,Resolution,xllupcorner,yllupcorner,FileName)
else
    raster_exportion = max(d,[],3)/1000 + dem;
    FileName = strcat('Max_Water_Surface_Elevation');
    SaveAsciiRaster(raster_exportion,Resolution,xllupcorner,yllupcorner,FileName)
end

if flag_waterquality == 1
    for i = 1:length(time_records)
        % Water Quality
        FileName = strcat('Pollutant_Concentration', num2str(time_map),'min');
        raster_exportion = Pol_Conc_Map(:,:,i);
        SaveAsciiRaster(raster_exportion,Resolution,xllupcorner,yllupcorner,FileName)
        if i == length(time_records)
            FileName = strcat('Max_Pollutant_Concentration', num2str(time_map),'min');
            raster_exportion = max(Pol_Conc_Map,[],3);
        end
    end
end
% Generate GIF Files of the Simulation
Inundation_Maps
