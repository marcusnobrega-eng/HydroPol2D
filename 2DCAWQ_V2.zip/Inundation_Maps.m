%%% Inundation Maps %%%
% Creates .GIF files from the saved data
% Last updated: 10/4/2021

close all
f = 1;
t_max = routing_time;
tfinal = t_max ; %t_max;
DEM_maps = gather(dem);
%% Plot Elevation Model
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'Elevation_Model.gif';
a_grid = Resolution;
b_grid = Resolution;
for t = 1:5
    % Draw plot
    z = DEM_maps;
    xmax = length(z(1,:));
    xend = xmax;
    ymax = length(z(:,1));
    yend = ymax;
    xbegin = 1;
    ybegin = 1;
    max_h = max(max(max(z)));
    h_max = round(max_h/10,0)*10*1.05;
    x_grid = [xbegin:1:xend]; y_grid = [ybegin:1:yend];
    z(z<=0)=inf;
    h_min = min(min(z));
    F = DEM_maps(y_grid,x_grid);
    zmax = max(max(max(z(~isinf(z)))));
    kk = surf(x_grid*a_grid,y_grid*b_grid,F);
    set(kk,'LineStyle','none')
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid h_min zmax])
    view(-15,45);
    colorbar
    caxis([h_min zmax]);
    colormap(jet)
    hold on
    title('Elevation','Interpreter','Latex','FontSize',12)
    k = colorbar ;
    ylabel(k,'Elevation (m)','Interpreter','Latex','FontSize',12)
    xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
    ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
    zlabel ('Elevation (m)','Interpreter','Latex','FontSize',12)
    drawnow
    % Capture the plot as an image
    frame = getframe(h);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    % Write to the GIF File
    if t == 1
        imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,filename,'gif','WriteMode','append');
    end
end
clf
%% Plot Water Surface Elevation and Depths
% Adjusting the size
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'WSE_and_Depths.gif';
set(gcf,'units','inches','position',[0,0,7,12])
for t = 1:f:length(time_records)
    subplot(2,1,1)
    t_title = time_records(t);
    % Draw plot for d = x.^n
    z = gather(d)/1000 + DEM_maps; %plotting only the excedance of the h_0
    z(z<=0)=inf;
    idx2 = d < depth_wse*1000;
    z(idx2) = nan;
    zmax = max(max(max(z)));
    zmin = min(min(min(z)));
    F = z(y_grid,x_grid,t);
    F(idx2(:,:,t)) = 0;
    surf(x_grid*a_grid,y_grid*b_grid,F);
    shading INTERP;
    set(gca,'Ydir','reverse')
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid zmin zmax])
    title(sprintf('Time(min) = %d',t_title),'Interpreter','Latex','FontSize',12)
    view(15,-75);
    colorbar
    caxis([zmin zmax]);
    colormap(jet)
    k = colorbar;
    ylabel(k,'WSE (m)','Interpreter','Latex','FontSize',12)
    xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
    ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
    zlabel ('WSE (m)','Interpreter','Latex','FontSize',12)
    drawnow
    subplot(2,1,2)
    z = gather(d/1000);
    z(z<=0)=inf;
    F = z(y_grid,x_grid,t);
    zmax = max(max(max(z(~isinf(z)))));
    surf(x_grid*a_grid,y_grid*b_grid,F);
    shading INTERP;
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid 0 zmax])
    title(sprintf('Time(min) = %d',t_title),'Interpreter','Latex','FontSize',12)
    view(0,90);
    colorbar
    caxis([0 zmax]);
    colormap(jet)
    k = colorbar;
    ylabel(k,'Depths (m)','Interpreter','Latex','FontSize',12)
    xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
    ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
    zlabel ('WSE (m)','Interpreter','Latex','FontSize',12)
    grid on
    % Capture the plot as an image
    frame = getframe(h);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    % Write to the GIF File
    if t == 1
        imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
    else
        imwrite(imind,cm,filename,'gif','WriteMode','append');
    end
end

%% Pollutant Concentration
if flag_waterquality == 1
    % Adjusting the size
    h = figure;
    axis tight manual % this ensures that getframe() returns a consistent size
    filename = 'Pollutant_Concentration.gif';
    set(gcf,'units','inches','position',[0,0,4,12])
    for t = 1:f:length(time_records)
        subplot(1,1,1)
        t_title = time_records(t);
        % Draw plot for d = x.^n
        z = Pol_Conc_Map; %plotting only the excedance of the h_0
        z(z<=0)=inf;
        z(idx2) = nan;
        zmax = max(max(max(z)));
        zmin = min(min(min(z)));
        F = z(y_grid,x_grid,t);
        F(idx2(:,:,t)) = 0;
        surf(x_grid*a_grid,y_grid*b_grid,F);
        shading INTERP;
        set(gca,'Ydir','reverse')
        axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid zmin zmax])
        title(sprintf('Time(min) = %d',t_title),'Interpreter','Latex','FontSize',12)
        view(0,90);
        colorbar
        caxis([zmin zmax]);
        colormap(jet)
        k = colorbar;
        ylabel(k,'Concentration (mg/L)','Interpreter','Latex','FontSize',12)
        xlabel(' x (m) ','Interpreter','Latex','FontSize',12)
        ylabel ('y (m) ','Interpreter','Latex','FontSize',12)
        zlabel ('Concentration (mg/L)','Interpreter','Latex','FontSize',12)
        drawnow
            % Capture the plot as an image
        frame = getframe(h);
        im = frame2im(frame);
        [imind,cm] = rgb2ind(im,256);
        % Write to the GIF File
        if t == 1
            imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
        else
            imwrite(imind,cm,filename,'gif','WriteMode','append');
        end
    end
end
close all