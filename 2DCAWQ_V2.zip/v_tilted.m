function [dem,imp] = v_tilted()
%% V-Tilted Watershed
% Goal - Assign parameters for cells according to the land use and land
% cover given by the imperviousness map

%% variables to determine the DEM
Delta_x = 20;
a_grid = Delta_x; % size of the grid cell
length_x = 800; % length of the hillslope
channel_x = 20; % width of the channel
length_y = 1000; % length of the channel
datum_zero = 0; %m - min level
resolution = a_grid; %m
slope_y = 0.02; %i %slope in y direction
slope_x = 0.05; %j %slope in x direction
channel_grid = channel_x;

%% Variables to assign to each cell: Soil Properties, Roughness Coefficient and other properties
%%%% Testing Overland Flow %%%%
% n_per = 0.015;
% n_imp = 0.15;
% ksat_per = 0.0001;
% ksat_imp = 0.0001;
% d_0_per = 0;
% d_0_imp = 0;
% h_0_per = 0;
% h_0_imp = 0;
% psi_per = 0.0001;
% psi_imp = 0.0001;
% I_0_per = 1000;
% I_0_imp = 1000;
% teta_sat_per = 0.09;
% teta_sat_imp = 0.09;
% teta_i_per = 0.08;
% teta_i_imp = 0.08;

%%%% Testing infiltration %%%%
% n_per = 0.3;
% n_imp = 0.018;
% ksat_per = 10.922;
% ksat_imp = 2;
% d_0_per = 0;
% d_0_imp = 0;
% h_0_per = 10;
% h_0_imp = 0.5;
% psi_per = 110;
% psi_imp = 5;
% I_0_per = 10;
% I_0_imp = 10;
% teta_sat_per = 0.454;
% teta_sat_imp = 0.2;
% teta_i_per = 0.01;
% teta_i_imp = 0.1;

%%%%% Testing infiltration with Clay Soil %%%%
n_per = 0.18;
n_imp = 0.018;% + 0.015*ppp;
ksat_per = 1.2;
ksat_imp = 2;
d_0_per = 0;
d_0_imp = 0;
h_0_per = 10;
h_0_imp = 0;
psi_per = 0.6;
psi_imp = 0.01;
I_0_per = 10;
I_0_imp = 10;
teta_sat_per = 0.386;
teta_sat_imp = 0.2;
teta_i_per = 0.01;
teta_i_imp = 0.1;


%% Calculations
%%% Preallocating arrays

y_1 = (length_y)/resolution;
x_1 = (length_x + channel_x)/resolution;
elevation_ = zeros(y_1,x_1); roughness_ = zeros(y_1,x_1);
d_0_ = zeros(y_1,x_1); h_0_ = zeros(y_1,x_1) ;psi_ = zeros(y_1,x_1);
ksat_ = zeros(y_1,x_1); teta_i_ = zeros(y_1,x_1);
teta_sat_ = zeros(y_1,x_1); I_0_ = zeros(y_1,x_1);
elevation = zeros(y_1,x_1); roughness = zeros(y_1,x_1);
d_0 = zeros(y_1,x_1); h_0 = zeros(y_1,x_1) ;psi = zeros(y_1,x_1);
ksat = zeros(y_1,x_1); teta_i = zeros(y_1,x_1);
teta_sat = zeros(y_1,x_1); I_0 = zeros(y_1,x_1);
desloc_j = (length_x+channel_x)/resolution;
[row, col] = find(elevation == min(min(elevation)));
x_exut = col; %outlet x coordinate
y_exut = row; %outlet y coordinate

% For loops for each plane
for i=1:(length_y)/resolution
    for j =1:(length_x + channel_x)/resolution
        if i==1
            if (j)*resolution <= channel_grid
                elevation_(i,j) = datum_zero;
                roughness_(i,j) = n_imp;
                d_0_(i,j) = d_0_imp;
                h_0_(i,j) = h_0_imp;
                psi_(i,j) = psi_imp;
                ksat_(i,j) = ksat_imp;
                teta_i_(i,j) = teta_i_imp;
                teta_sat_(i,j) = teta_sat_imp;
                I_0_(i,j) = I_0_imp;                
            else                
                elevation_(i,j) = datum_zero + slope_x*(j-1)*resolution;
                roughness_(i,j) = n_per;
                d_0_(i,j) = d_0_per;
                h_0_(i,j) = h_0_per;
                psi_(i,j) = psi_per;
                ksat_(i,j) = ksat_per;
                teta_i_(i,j) = teta_i_per;
                teta_sat_(i,j) = teta_sat_per;
                I_0_(i,j) = I_0_per;            
            end           
        else
            if (j)*resolution <= channel_grid
                elevation_(i,j) = elevation_(i-1,j) + resolution*slope_y;
                roughness_(i,j) = n_imp;
                d_0_(i,j) = d_0_imp;
                h_0_(i,j) = h_0_imp;
                psi_(i,j) = psi_imp;
                ksat_(i,j) = ksat_imp;
                teta_i_(i,j) = teta_i_imp;
                teta_sat_(i,j) = teta_sat_imp;
                I_0_(i,j) = I_0_imp;
            else
                elevation_(i,j) = elevation_(i-1,j) + resolution*slope_y;
                roughness_(i,j) = n_per;
                d_0_(i,j) = d_0_per;
                h_0_(i,j) = h_0_per;
                psi_(i,j) = psi_per;
                ksat_(i,j) = ksat_per;
                teta_i_(i,j) = teta_i_per;
                teta_sat_(i,j) = teta_sat_per;
                I_0_(i,j) = I_0_per;
            end
        end
    end
end
for i = 1:(length_y)/resolution
    for j = 1:(2*desloc_j - 1)
        if j<=desloc_j
            elevation(i,j +desloc_j-1) = elevation_(i,j);
            roughness(i,j + desloc_j-1) = roughness_(i,j);
            d_0(i,j +desloc_j-1) = d_0_(i,j);
            h_0(i,j +desloc_j-1) = h_0_(i,j);
            psi(i,j +desloc_j-1) = psi_(i,j);
            ksat(i,j +desloc_j-1) = ksat_(i,j);
            teta_i(i,j +desloc_j-1) = teta_i_(i,j);
            teta_sat(i,j +desloc_j-1) = teta_sat_(i,j);
            I_0(i,j +desloc_j-1) = I_0_(i,j);
        else
            number_j = j-desloc_j;
            elevation(i,desloc_j - number_j) = elevation(i,j);
            roughness(i,desloc_j - number_j) = roughness(i,j);
            d_0(i,desloc_j - number_j) = d_0(i,j);
            h_0(i,desloc_j - number_j) = h_0(i,j);
            psi(i,desloc_j - number_j) = psi(i,j);
            ksat(i,desloc_j - number_j) = ksat(i,j);
            teta_i(i,desloc_j - number_j) = teta_i(i,j);
            teta_sat(i,desloc_j - number_j) = teta_sat(i,j);
            I_0(i,desloc_j - number_j) = I_0(i,j);
        end
    end
end
% Chaning names to match with the main file
imp = zeros(size(roughness));
idx1 = roughness == min(min(roughness));
imp(idx1) = 1;
idx2 = roughness == max(max(roughness));
imp(idx2) = 2;
dem = elevation;
end