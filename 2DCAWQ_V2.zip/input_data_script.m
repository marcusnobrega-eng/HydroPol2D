%%%%%%%%%%%%%% INPUT DATA %%%%%%%%%%%%%%%%%%%
input_table = readtable('general_data.csv');
input_data = table2array(input_table(:,2));
Resolution = input_data(1,1);
routing_time = input_data(2,1);
time_step_model = input_data(3,1)/60; % Attention, the model required time-step in min 
min_time_step = input_data(4,1);
max_time_step = input_data(5,1);
time_step_increments = input_data(6,1);
time_step_change = input_data(7,1);
time_step_matrices = input_data(8,1);
factor_cells = input_data(9,1);
flow_tolerance = input_data(10,1);
depth_tolerance = input_data(11,1);
flag_rainfall = input_data(12,1);
outlet_type = input_data(13,1);
slope_outlet = input_data(14,1);
x_outlet_begin = input_data(15,1);
x_outlet_end = input_data(16,1);
y_outlet_begin = input_data(17,1);
y_outlet_end = input_data(18,1);
record_time_maps = input_data(19,1);
record_time_hydrographs = input_data(20,1);
slope_min = input_data(21,1);
alfa = input_data(22,1);
flag_inflow = input_data(23,1);
flag_abstraction = input_data(24,1);
flag_matrices = input_data(25,1);
xmin = input_data(25,1);
ymin = input_data(26,1);
xmax = input_data(27,1);
ymax = input_data(28,1);
% Coordinates
xllupcorner = input_data(29,1);
yllupcorner = input_data(30,1);
% WSE data
flag_wse = input_data(31,1);
depth_wse = input_data(32,1);
% Water Balance
flag_waterbalance = input_data(33,1);
% Water Quality
flag_waterquality = input_data(34,1);
% ADD
ADD = input_data(35,1);
% Time_step
flag_timestep = input_data(36,1);
%%%%%%%%%%%%%% LULC DATA %%%%%%%%%%%%%%%%%%%
input_table = readtable('LULC_data.csv');
input_data = table2array(input_table(1:6,2:14)); % numbers
lulc_parameters = input_data(1:6,2:13);
% LULC Index
LULC_index = input_data(:,1);
% Rainfall
input_table = readtable('Rainfall_Intensity_Data.csv');
input_data = table2array(input_table);
intensity_rainfall = input_data(:,2); % mm/h
time_rainfall = input_data(:,1); % min
time_step_rainfall = input_data(2,1) - input_data(1,1); % min
rainfall_duration = input_data(2,1) - input_data(1,1); % min
% Inflow
input_table = readtable('Inflow_Hydrograph.csv');
input_data = table2array(input_table);
inflow_discharge = input_data(~isnan(input_data(:,1)),2); % mm/h
time_inflow = input_data(~isnan(input_data(:,1)),1); % min
time_step_inflow = input_data(2,1) - input_data(1,1); % min
inlet_cells = input_data(~isnan(input_data(:,3)),3:4);
n_inlets = length(inlet_cells(~isnan(inlet_cells(:,1))));
if n_inlets == 0
    error('Please, insert the inlet point(s) in the Inflow_Hydrograph.csv file')
end
Area = Resolution^2*n_inlets; % m2
inflow_hydrograph_rate = inflow_discharge/Area*1000*3600; % mm/h
clear input_data input_table