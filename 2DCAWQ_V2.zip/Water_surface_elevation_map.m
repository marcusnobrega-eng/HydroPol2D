% Water Surface Elevations and 3-D DEM

subplot(1,2,1)
d_minimum = 1; % mm
idx = d_t <= d_minimum;
wse = zeros(ny_max,nx_max);
elevation_new = gather(elevation);
elevation_new(idx) = 0;
wse = (elevation_new + gather(d_t)/1000);
wse(idx) = nan;
idx = wse > 0;
surf(wse); hold on
zmax = max(max(wse(idx)));
zmin = min(min(wse(idx)));
% zmin = min(min(wse));
zlim([zmin,zmax]);
kk = colorbar;
ylabel(kk,'WSE (m)','Interpreter','Latex','FontSize',12)
colormap jet
shading interp
caxis([zmin zmax]);
xlabel('x (cells)','Interpreter','Latex','FontSize',12)
ylabel('y (cells)','Interpreter','Latex','FontSize',12)
view(0,90);
subplot(1,2,2)
surf(gather(elevation)); 
hold on;
zmax = max(max(gather(elevation)));
zzzz = gather(inflow_cells)*zmax;
surf(zzzz);
zzzz = gather(outlet_index)*zmax;
surf(zzzz);
zmax = max(zmax,max(max(zzzz)));
zmin = min(min(gather(elevation)));
% zmin = 200;
% zmax = 210;
zlim([zmin,zmax]);
caxis([zmin zmax]);
xlabel('x (cells)','Interpreter','Latex','FontSize',12)
ylabel('y (cells)','Interpreter','Latex','FontSize',12)
zlabel('Elevation (m)','Interpreter','Latex','FontSize',12)
kk = colorbar;
ylabel(kk,'Elevation (m)','Interpreter','Latex','FontSize',12)
colormap jet
shading interp
view(0,90);

