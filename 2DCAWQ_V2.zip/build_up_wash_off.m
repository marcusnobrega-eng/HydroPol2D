function [B_t,P_conc,Out_Conc] = build_up_wash_off(C_3,C_4,qout_left_t,qout_right_t,qout_up_t,qout_down_t,outlet_flow,B_t,time_step,nx_max,ny_max,cell_area,outlet_index);

%   This function estimates the build-up and wash-off distribution
q_out_t = cat(3,qout_left_t,qout_right_t,qout_up_t,qout_down_t,outlet_flow); % mm/h
W_out_t = C_3.*q_out_t.^(C_4).*B_t;
tot_W_out = sum(W_out_t,3);
tot_q_out = sum(q_out_t,3);

W_out_left_t = W_out_t(:,:,1);
W_out_right_t = W_out_t(:,:,2);
W_out_up_t = W_out_t(:,:,3);
W_out_down_t = W_out_t(:,:,4);
W_out_outlet_t = W_out_t(:,:,5);
% W_out_outlet_t = W_out_t(:,:,5);

W_in_left_t = [zeros(ny_max,1),W_out_right_t(:,1:(nx_max-1))];
W_in_right_t = [W_out_left_t(:,(2:(nx_max))) zeros(ny_max,1)];
W_in_up_t = [zeros(1,nx_max) ; W_out_down_t(1:(ny_max-1),:)];
W_in_down_t = [W_out_up_t(2:(ny_max),:) ; zeros(1,nx_max)];
W_in_t = cat(3,W_in_left_t,W_in_right_t,W_in_up_t,W_in_down_t);

B_t = max(B_t + (sum(W_in_t,3) - tot_W_out)*time_step/60,0); % Refreshing Available Depth
if isnan(max(max(B_t)))
    error('Instability')
end
P_conc = max(1000*(tot_W_out)./(tot_q_out/1000*cell_area),0); % mg/L
idx = outlet_index == 1;
% Outlet Concentration
Out_Conc = max(1000*sum(sum(W_out_outlet_t(idx)))/(sum(sum(outlet_flow))/1000*cell_area),0); % mg/L
end

