function [qout_left,qout_right,qout_up,qout_down,outlet_flow,d_t_cell,I_tot_end_cell,I] = CA_Routing(elevation_cell,elevation_left_t,elevation_right_t,elevation_up_t,elevation_down_t,d_t_cell,d_left_cell,d_right_cell,d_up_cell,d_down_cell,roughness_cell,cell_area,time_step,h_0_cell,Resolution,I_tot_end_cell,outlet_check,outlet_type,slope_outlet)
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                 %
%                 Produced by Marcus Nobrega Gomes Junior         %
%                 e-mail:marcusnobrega.engcivil@gmail.com         %
%                           September 2021                        %
%                                                                 %
%                 Last Updated: 11 September, 2021                %
%                                                                 %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


%§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
%
%   -----  SYNTAX  -----
%   [output_matrix] = resize_matrix(input_matrix,domain,ymin_domain_abstracted,ymax_domain_abstracted,xmin_domain_abstracted,xmax_domain_abstracted,dymin_matrix,dymax_matrix,dxmin_matrix,dxmax_matrix);
%   -----  DESCRIPTION  -----
%   This function estimates the transfered volume from a cell to the
%   neighbour cells using a weighing approach in terms of the available
%   volume in the neighbour cells
%§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
    d_t_min = 1e-6; % m
    idx2 = d_t_cell < d_t_min*1000;
    %%% adding minimum slope to do calculations
    h_min = 1e-6;% m 
    I_tot_end_previous = I_tot_end_cell;
%     delta_h = delta_h_matrix;
    % Notation
    %   <-I-> (left right up down) = [left ; right ; up; down]
        depth_cell = d_t_cell./1000; % meters
        wse_cell = elevation_cell + depth_cell;
%         delta_h = repmat(wse_cell,[1 1 5]);
        delta_h(:,:,1) = (wse_cell - elevation_left_t - d_left_cell./1000);
        delta_h(:,:,2) = (wse_cell - elevation_right_t - d_right_cell./1000);
        delta_h(:,:,3) = (wse_cell - elevation_up_t - d_up_cell./1000);    
        delta_h(:,:,4) = (wse_cell - elevation_down_t - d_down_cell./1000);     
        % Correcting delta_h
        delta_h(isnan(delta_h)) = 0; % TESTING

        %%%%% CHECKED 9/28/2021 %%%%% 
    % Alternative 1 - It is quicker
    % Checking delta_h for the outlet
        if outlet_type == 1
            S_0 = slope_outlet;
            % V = h * area
            % % % % % % %         delta_h_outlet = delta_h(5);
            delta_h(:,:,5) = (S_0*Resolution*outlet_check);
            %%%%% CHECKED 9/28/2021 %%%%% 
        else
            S_0 = (outlet_check.*depth_cell.^(-1/6)).*sqrt(9.81).*roughness_cell;
            delta_h(:,:,5) = (S_0*Resolution);
        end
        
        % Boundary Conditions
        delta_h(:,1,1) = 0; % Left
        %     direction = ones(size(delta_h(:,:,1)));
        delta_h(:,end,2) = 0; % Right
        delta_h(1,:,3) = 0; % Up
        delta_h(end,:,4) = 0; % Down
        idx = delta_h < h_min;
        delta_h(idx) = 0;
        % Available Volumes
        Vol = cell_area*delta_h; % 5-D Array      
    % Max h
           maxh = max(delta_h,[],3);
           %%%%% CHECKED 9/28/2021 %%%%% 
    % Alternative 2 - It last longer
    % delta_h(delta_h<h_min) = 0;

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Alternative 1 - Faster
        % Minimum
        c = 10000;
        Vol_nan = Vol;
        Vol_nan(idx) = c;
        Vol_min_matrix = min(Vol_nan,[],3);
      
        % Total Volume
         Vol_tot = sum(Vol,3);
        
        % Weights
        weight = Vol./(Vol_tot + Vol_min_matrix);
        weight_max = max(weight,[],3); 

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Velocity to the cell with the highest gradient
        v_m = min(sqrt(9.81.*depth_cell),1./roughness_cell.*((max(depth_cell - h_0_cell/1000,0))).^(2/3).*sqrt(maxh./Resolution));
        % Estimated Volume that goes to the cell with the highest gradient
%         I_m = v_m.*depth_cell*Resolution*time_step*60; % Velocity x Area x Time_step (m3)
        % Total outflow volume
        % I_tot_end = min(depth_cell*cell_area,I_m/max(weight),Vol_min_matrix + I_tot_begin);
        I_tot_end_cell = min(depth_cell.*cell_area,v_m.*depth_cell./weight_max*(Resolution*time_step*60)); % m3
        I_tot_end_cell = min(I_tot_end_cell,I_tot_end_previous + Vol_min_matrix);
        I_tot_end_cell(idx2) = 0;  % If the depth is smaller than dmin ATTENTION HERE
        %     I_tot_end_cell = round(I_tot_end_cell,6);
        % Outflow Volume to each direction
        I = weight.*I_tot_end_cell; % m3
        I_tot_end_cell = sum(I,3);% VERY MUCH ATTENTION HERE
        qout = I./(time_step*60)/(cell_area)*1000*3600;
%         Flow = weight.*I_tot_end_cell/(time_step*60)/(cell_area)*1000*3600; % mm/h
        %     Flow = round(I/(time_step*60)/(cell_area)*1000*3600,16,'significant'); % mm/h
        qout_left = qout(:,:,1);
        qout_right = qout(:,:,2);
        qout_up = qout(:,:,3);
        qout_down = qout(:,:,4);
        outlet_flow = qout(:,:,5);
%         Outflow = I(:,:,1) + I(:,:,2) + I(:,:,3) + I(:,:,4) + I(:,:,5);
        % Final depth at the cell
        d_t_cell = d_t_cell - I_tot_end_cell/cell_area*1000; % final depth in mm;
    
end