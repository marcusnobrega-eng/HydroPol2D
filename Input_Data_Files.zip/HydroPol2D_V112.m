%% HydroPol2D Model - V11
% Developer: Marcus Nobrega Gomes Jr., 
% Ph.D. - University of Sao Paulo / Sao Carlos School of Engineering
% Ph.D. - University of Texas at San Antonio

% % % % % % % % % % % % % Model Status % % % % % % % % % % % % %
% ---------- Version 11.0 -------------
% Last Update - 6/22/2023
% Questions and Collaboration: Please contact marcusnobrega.engcivil@gmail.com

%% Pre-Processing
clear all; clc;
model_folder = 'General_Data_HydroPol2D.xlsx'; % Please state the name of the folder of your input data
input_table = readtable(model_folder); 

% Load Model Functions
HydroPol2D_tools = char(table2cell(input_table(9,31)));
addpath(genpath(char(HydroPol2D_tools)));

HydroPol2D_preprocessing % Run HydroPol2D pre-processing

%% Sensitivity Analysis
% Sensitivity_Analysis_HydroPol2D; % If you want to run a sensitivity
% analysis, please run this code.

%% Main While Loop
% outlet_index = Wshed_Properties.perimeter; % If you want to use the whole
% boundary of the domain as the outlet, you should activate this code.

HydroPol2D_Main_While; % Runs the Main While Loop of the Model

%% Post-Processing Results
close all
post_processing